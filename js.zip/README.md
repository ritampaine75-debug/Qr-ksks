# QR Studio

> **Create. Customize. Scan. Export.**  
> A powerful, all-in-one QR Code studio built for fast, beautiful, and customizable QR experiences.

**QR Studio** is a production-ready, client-side web application crafted in pure HTML5, CSS3, and Vanilla JavaScript. It delivers a modern, desktop-and-mobile-optimized QR Code creation studio, a real-time vector and canvas rendering engine, an interactive hardware-accelerated camera scanner, and a full preset design template suite.

---

## Table of Contents

1. [Key Features](#key-features)
2. [Supported QR Data Formats](#supported-qr-data-formats)
3. [Project Structure](#project-structure)
4. [How to Run Locally](#how-to-run-locally)
5. [How to Deploy to Static Hosting](#how-to-deploy-to-static-hosting)
   - [Vercel](#vercel)
   - [Netlify](#netlify)
   - [GitHub Pages](#github-pages)
6. [Clean URLs & Client-Side Routing](#clean-urls--client-side-routing)
7. [Camera & Hardware Permissions](#camera--hardware-permissions)
8. [Privacy & Security Architecture](#privacy--security-architecture)
9. [External Libraries & Dependencies](#external-libraries--dependencies)
10. [PWA & Offline Capability](#pwa--offline-capability)
11. [Troubleshooting Guide](#troubleshooting-guide)
12. [Developer Information](#developer-information)
13. [License](#license)

---

## Key Features

- **21 Structured Data Types**: Full form wizards for Wi-Fi auto-connect, vCard 3.0 contacts, UPI payments, cryptocurrencies, calendar schedules, geo pins, social links, and custom data.
- **Master Design Studio**:
  - **Granular Color Control**: Custom foreground, background, eye outer ring, eye inner core, preset palettes, and safe transparent backgrounds.
  - **Gradients**: Custom linear (0°–360° angle) and radial gradients.
  - **Module Shapes**: Square, Rounded, Dots (Circles), Classy Diamonds, and Extra-Rounded Pills.
  - **Finder Eye Shapes**: Square, Rounded Square, Circle Ring, Leaf, and Shield frames paired with Square, Dot, Rounded, Diamond, or Star centers.
  - **Center Logo Integration**: Custom logo upload (PNG, JPG, SVG, WebP) or preset icon library with automatic safe margin cutout and error correction recommendations.
  - **Atmosphere Effects**: Drop shadows, neon outer glow, and soft framing borders.
  - **Live Scannability Advisor**: Instant WCAG luminance contrast calculation, quiet-zone verification, and a 1-click **"Optimize for Scanning"** button.
- **Animated Previews**: Real-time generation animations (circular reveal, fade-in, scale bounce, subtle pulse) with full support for `prefers-reduced-motion`.
- **Multi-Format Vector & Raster Export**:
  - **SVG**: Pure scalable vector graphics XML with zero raster degradation.
  - **PNG**: High-definition lossless raster up to 2048px (2K).
  - **JPEG & WebP**: Optimized web formats.
  - **Clipboard Copy**: Direct image blob copy and SVG markup copy.
  - **Print Sheets**: Clean printable sheets formatted with custom labels and scan instructions.
- **Camera & File Scanner**:
  - Real-time video camera feed with reticle overlay and laser sweep animation.
  - Front / rear camera switching and hardware flashlight/torch toggle.
  - Image upload, drag-and-drop, and clipboard paste (Ctrl+V) scanning.
  - **Scan & Download**: Automatically decode any existing QR code, inspect its security credentials, and recreate a clean downloadable vector QR with 1 click.
- **13+ Curated Design Templates**: Pre-configured styles across Minimal, Business, Dining Menus, Fintech, and Social Media.
- **Local History**: Stored entirely in browser LocalStorage with search, filtering, thumbnail previews, re-opening in studio, duplication, and single-click deletion.
- **Zero Backend**: 100% client-side execution without tracking, analytics cookies, or databases.

---

## Supported QR Data Formats

1. **Website URL** (`https://...` or `http://...`)
2. **Plain Text** (Multi-line text notes, serial numbers, character counter)
3. **Wi-Fi Network** (`WIFI:T:WPA;S:ssid;P:pass;H:false;;` — WPA/WPA2/WPA3, WEP, Open, Hidden)
4. **vCard Contact** (RFC 2426 vCard 3.0 specification with name, phone, email, organization, website)
5. **Email Message** (`mailto:...` with recipient, subject line, pre-filled body)
6. **Phone Number** (`tel:...`)
7. **SMS Message** (`sms:...` with recipient and pre-filled body)
8. **WhatsApp Chat** (`https://wa.me/...` with pre-filled greeting)
9. **UPI Payment** (`upi://pay?pa=...&pn=...&am=...&cu=INR` for Indian digital payments)
10. **Cryptocurrency** (Bitcoin, Ethereum, Solana, Litecoin addresses with amounts)
11. **Calendar Event** (RFC 5545 iCalendar `BEGIN:VEVENT` format with start/end timestamps and location)
12. **Geo Location** (`geo:lat,lng` and Google Maps query links)
13. **Social Media Link** (Bio link hubs, personal portfolios)
14. **App Store Link** (iOS App Store & Google Play Store links)
15. **YouTube** (Video and channel URLs)
16. **Instagram** (Profiles and post links)
17. **Facebook** (Pages and profiles)
18. **X / Twitter** (Handles and tweet share links)
19. **Telegram** (Usernames and channels)
20. **LinkedIn** (Personal and company profiles)
21. **Custom Data** (Raw formatted string for proprietary applications)

---

## Project Structure

```
QR-Studio/
├── index.html              # Homepage & SPA interactive showcase
├── generator.html          # QR Generator with 21 data types
├── editor.html             # Full Design Studio & Customizer
├── scanner.html            # Camera & File Scanner + Recreate engine
├── templates.html          # 13+ Curated Design Presets
├── history.html            # Local History manager
├── settings.html           # Appearance, output defaults, and privacy
├── about.html              # Product details & developer credits
├── 404.html                # Static redirect fallback for GitHub Pages
├── _redirects              # Netlify clean URL rewrite rules
├── vercel.json             # Vercel clean URL rewrite configuration
├── manifest.json           # Progressive Web App manifest
├── service-worker.js       # Offline asset caching service worker
├── README.md               # Project documentation
├── LICENSE                 # MIT License
│
├── css/
│   ├── global.css          # Design system variables, typography, reset, buttons, forms
│   ├── components.css      # Topbar, bottom mobile nav, preview card, scannability meter, modals
│   ├── generator.css       # 21-type selector grid and dynamic field animations
│   ├── editor.css          # Two-column layout, color pickers, eye shapes, logo dropzone
│   ├── scanner.css         # Camera viewfinder, reticle, laser animation, scan result card
│   └── responsive.css      # Breakpoints for mobile, tablet, and touch target optimization
│
├── js/
│   ├── vendor/
│   │   ├── qrcode.js       # Bundled zero-dependency Kazuhiko Arase QR matrix generator
│   │   └── jsqr-fallback.js# Scanner fallback stub
│   ├── app.js              # Application bootstrapper & settings controller
│   ├── router.js           # Clean URL routing & History API controller
│   ├── qr-engine.js        # Core rendering engine for Canvas & Scalable Vector SVG
│   ├── generator.js        # Dynamic type forms & live preview manager
│   ├── editor.js           # Design controls, color swatches, logo upload, and export actions
│   ├── scanner.js          # Camera video stream, file upload, security check, and recreate
│   ├── templates.js        # Preset template definitions and instant editor loading
│   ├── history.js          # LocalStorage persistence, search, download, and deletion
│   ├── export.js           # Multi-resolution PNG, SVG, JPEG, WebP, and print sheet engine
│   ├── storage.js          # Persistence wrapper for history and preferences
│   ├── ui.js               # Toast notification system, dialog modals, and theme manager
│   └── utils.js            # Protocol formatters, payload parser, and WCAG contrast analyzer
│
└── assets/
    ├── icons/              # SVG icons for all 21 types and UI elements
    ├── images/             # App icons (192px, 512px) and favicon
    └── logos/              # Preset center badges (QR, link, wifi, star, shield, etc.)
```

---

## How to Run Locally

Because QR Studio is a pure client-side static application, you do not need to install any build tools, Node modules, or package managers.

### Option 1: Python HTTP Server (Recommended)

Open your terminal, navigate to the `QR-Studio` directory, and run:

```bash
# Python 3
python3 -m http.server 8000
```

Then open your browser and navigate to:
```
http://localhost:8000
```

### Option 2: Live Server in VS Code

1. Open the `QR-Studio` folder in Visual Studio Code.
2. Install the **Live Server** extension.
3. Right-click `index.html` and select **"Open with Live Server"**.

### Option 3: Direct File Opening

You can double-click `index.html` or any `.html` file to open it directly in modern browsers (Chrome, Edge, Firefox, Safari).  
*Note: Due to browser security restrictions, camera scanning and service workers require an `http://` or `https://` origin.*

---

## How to Deploy to Static Hosting

### Vercel
QR Studio includes a pre-configured `vercel.json` file. To deploy:
1. Push the repository to GitHub.
2. Import the project in Vercel.
3. Keep the default settings (Framework: **Other**, Build command: *leave empty*, Output directory: *root*).
4. Click **Deploy**. Clean URLs (`/generator`, `/editor`, etc.) will work out of the box.

### Netlify
QR Studio includes a pre-configured `_redirects` file. To deploy:
1. Connect your repository to Netlify or drag and drop the `QR-Studio` folder directly into the Netlify Drop dashboard.
2. Deployment completes in seconds with clean URL support.

### GitHub Pages
1. Push the contents of `QR-Studio` to your repository's `main` branch or a `gh-pages` branch.
2. Go to **Settings** &rarr; **Pages** &rarr; Select `main` branch as the publishing source.
3. The included `404.html` and `router.js` automatically handle direct clean URL visits (e.g. `https://username.github.io/repository/generator`) by rewriting the path back to the client router without 404 errors.

---

## Clean URLs & Client-Side Routing

The application uses clean, professional routes rather than hash fragments:
- `/generator`
- `/editor`
- `/scanner`
- `/templates`
- `/history`
- `/settings`
- `/about`

Navigation links use the HTML5 **History API** (`history.pushState` and `history.replaceState`) for instant transitions without full-page reloads. When a user opens any page directly (e.g. `generator.html` or `/generator`), the respective page initializes its controller seamlessly.

---

## Camera & Hardware Permissions

- **User Opt-In Only**: Camera permissions are never requested upon initial page load. The prompt is only triggered when the user explicitly clicks the **"Start Camera"** button on the Scanner page.
- **Secure Context (HTTPS)**: Browsers require an HTTPS connection (or `localhost`) to access camera video hardware.
- **Camera Switching & Torch**: The scanner detects whether multiple cameras (front/rear) or hardware flashlights are available and provides floating controls inside the viewfinder.

---

## Privacy & Security Architecture

- **100% Client-Side**: All QR matrix math, vector SVG drawing, logo composition, and scanning occur in your browser's local sandbox memory.
- **Zero Telemetry**: No third-party tracking scripts, analytics cookies, or remote databases.
- **Security Domain Verification**: When scanning web URLs, QR Studio shows the parsed target domain before opening and alerts the user if the payload contains suspicious schemes (`javascript:`, `data:`, or executable file downloads).
- **Sanitized Outputs**: All rendered HTML strings are escaped to prevent Cross-Site Scripting (XSS).

---

## External Libraries & Dependencies

QR Studio is built with zero heavy frameworks. To ensure maximum reliability and ease of deployment:
1. **Kazuhiko Arase QR Code Algorithm**:
   - Location: `js/vendor/qrcode.js`
   - License: MIT License
   - Purpose: Bundled, zero-dependency QR code matrix calculations supporting versions 1 through 40 and error correction levels L, M, Q, and H with full UTF-8 support.
2. **Barcode Detection API (Native)**:
   - Built into modern Chromium browsers (Chrome, Edge, Samsung Internet) for hardware-accelerated QR code reading.
3. **jsQR (Fallback Scanner)**:
   - CDN: `https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.min.js` with local fallback stub `js/vendor/jsqr-fallback.js`.
   - Purpose: Provides cross-browser fallback scanning for platforms without native BarcodeDetector support.

---

## PWA & Offline Capability

QR Studio includes a complete Web App Manifest (`manifest.json`) and a cache-first Service Worker (`service-worker.js`).
- **Installable**: Can be installed as a standalone desktop or mobile application on Chrome, Edge, and iOS Safari.
- **Offline First**: Once loaded, all core features (Generator, Editor, History, Templates, Settings) continue functioning without internet access.

---

## Troubleshooting Guide

- **Camera Not Starting**: Ensure your site is served over `https://` (or `localhost`) and that browser camera permissions are granted. If on desktop without a webcam, use the **Upload Image** tab.
- **Scan Detection Failure**: If an uploaded QR image does not decode, check that the image is in focus, has sufficient lighting, and includes an intact quiet-zone margin around the code.
- **Low Scannability Warning**: If a generated QR code is hard to scan on older phones, click the **"Optimize for Scanning"** button in the Editor to automatically boost contrast and upgrade Error Correction to High (H).

---

## Developer Information

- **Developer**: Ritam
- **Instagram**: [@ritam_2024_0](https://instagram.com/ritam_2024_0)
- **Contact Email**: [ritampaine75@gmail.com](mailto:ritampaine75@gmail.com)

---

## License

This project is licensed under the terms of the [MIT License](LICENSE).
