/**
 * QR STUDIO - SERVICE WORKER
 * Offline Caching & Static Asset Resilience
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

const CACHE_NAME = "qr-studio-cache-v1";

const ASSETS_TO_CACHE = [
  "/",
  "/index.html",
  "/generator.html",
  "/editor.html",
  "/scanner.html",
  "/templates.html",
  "/history.html",
  "/settings.html",
  "/about.html",
  "/404.html",
  "/css/global.css",
  "/css/components.css",
  "/css/generator.css",
  "/css/editor.css",
  "/css/scanner.css",
  "/css/responsive.css",
  "/js/vendor/qrcode.js",
  "/js/vendor/jsqr-fallback.js",
  "/js/utils.js",
  "/js/storage.js",
  "/js/ui.js",
  "/js/qr-engine.js",
  "/js/generator.js",
  "/js/editor.js",
  "/js/scanner.js",
  "/js/templates.js",
  "/js/history.js",
  "/js/export.js",
  "/js/router.js",
  "/js/app.js",
  "/assets/images/favicon.png",
  "/assets/images/icon-192.png",
  "/assets/images/icon-512.png"
];

// Install Event
self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch((err) => {
        console.warn("ServiceWorker precache partial skip:", err);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activate Event: Clear older caches
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((k) => {
          if (k !== CACHE_NAME) {
            return caches.delete(k);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch Event: Cache First, Network Fallback
self.addEventListener("fetch", (e) => {
  // Only handle GET requests
  if (e.request.method !== "GET") return;

  e.respondWith(
    caches.match(e.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(e.request)
        .then((networkResponse) => {
          // If valid response, clone and cache for next time
          if (networkResponse && networkResponse.status === 200 && networkResponse.type === "basic") {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(e.request, clone));
          }
          return networkResponse;
        })
        .catch(() => {
          // Fallback to index.html for page navigation when offline
          if (e.request.mode === "navigate") {
            return caches.match("/index.html");
          }
        });
    })
  );
});
