/**
 * QR STUDIO - MASTER QR CODE RENDERING ENGINE
 * Canvas & SVG Vector Renderer with Advanced Styling, Gradients, Shapes, and Eyes
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  const DEFAULT_DESIGN = {
    // Colors
    fgColor: "#000000",
    bgColor: "#ffffff",
    transparentBg: false,
    gradientType: "none", // 'none', 'linear', 'radial'
    gradientColor2: "#4f46e5",
    gradientAngle: 45,

    // Eyes
    eyeOuterColor: "", // empty = inherit fg
    eyeInnerColor: "", // empty = inherit fg
    eyeOuterStyle: "square", // 'square', 'rounded', 'circle', 'leaf', 'shield'
    eyeInnerStyle: "square", // 'square', 'dot', 'rounded', 'diamond', 'star'

    // Modules
    moduleStyle: "square", // 'square', 'rounded', 'dots', 'classy', 'extra-rounded'

    // Logo
    logoSrc: "",
    logoSize: 0.22, // 10% to 35% of QR width
    logoPadding: 1, // quiet zone modules around logo
    logoBgShape: "circle", // 'circle', 'rounded', 'square', 'none'
    logoBgColor: "#ffffff",

    // Effects
    effect: "none", // 'none', 'shadow', 'glow', 'border'
    effectColor: "rgba(99, 102, 241, 0.4)",

    // Dimensions & ECC
    size: 512,
    margin: 2,
    ecc: "M" // 'L', 'M', 'Q', 'H'
  };

  class QREngine {
    constructor() {
      this.cachedQR = null;
      this.cachedText = "";
      this.cachedECC = "";
    }

    /**
     * Get or build QR Matrix using QRCodeGenerator
     */
    getMatrix(text, ecc = "M") {
      if (this.cachedQR && this.cachedText === text && this.cachedECC === ecc) {
        return this.cachedQR;
      }
      const levelMap = {
        L: QRErrorCorrectLevel.L,
        M: QRErrorCorrectLevel.M,
        Q: QRErrorCorrectLevel.Q,
        H: QRErrorCorrectLevel.H
      };
      const eccLevel = levelMap[ecc] !== undefined ? levelMap[ecc] : QRErrorCorrectLevel.M;
      const qr = QRCodeGenerator(text || "https://qrstudio.app", eccLevel);
      this.cachedQR = qr;
      this.cachedText = text;
      this.cachedECC = ecc;
      return qr;
    }

    /**
     * Determine if a cell is inside one of the three Finder Patterns (Eyes)
     */
    getEyeLocation(row, col, count) {
      // Top-Left Eye
      if (row < 7 && col < 7) {
        return { isEye: true, which: "TL", r: row, c: col, originR: 0, originC: 0 };
      }
      // Top-Right Eye
      if (row < 7 && col >= count - 7) {
        return { isEye: true, which: "TR", r: row, c: col - (count - 7), originR: 0, originC: count - 7 };
      }
      // Bottom-Left Eye
      if (row >= count - 7 && col < 7) {
        return { isEye: true, which: "BL", r: row - (count - 7), c: col, originR: count - 7, originC: 0 };
      }
      return { isEye: false };
    }

    /**
     * Determine if cell is within logo clear zone
     */
    isInLogoZone(row, col, count, hasLogo, logoSizeRatio, logoPadding) {
      if (!hasLogo) return false;
      const center = count / 2;
      const halfSize = (count * logoSizeRatio) / 2 + logoPadding;
      return (
        row >= center - halfSize &&
        row <= center + halfSize &&
        col >= center - halfSize &&
        col <= center + halfSize
      );
    }

    /**
     * Create gradient on canvas context
     */
    createCanvasGradient(ctx, width, height, type, color1, color2, angleDeg = 45) {
      if (type === "linear") {
        const rad = (angleDeg * Math.PI) / 180;
        const x0 = width / 2 - (Math.cos(rad) * width) / 2;
        const y0 = height / 2 - (Math.sin(rad) * height) / 2;
        const x1 = width / 2 + (Math.cos(rad) * width) / 2;
        const y1 = height / 2 + (Math.sin(rad) * height) / 2;
        const grad = ctx.createLinearGradient(x0, y0, x1, y1);
        grad.addColorStop(0, color1);
        grad.addColorStop(1, color2);
        return grad;
      } else if (type === "radial") {
        const cx = width / 2;
        const cy = height / 2;
        const r = Math.max(width, height) / 2;
        const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
        grad.addColorStop(0, color1);
        grad.addColorStop(1, color2);
        return grad;
      }
      return color1;
    }

    /**
     * Render QR Code to HTML5 Canvas
     */
    async renderToCanvas(canvas, text, userOptions = {}) {
      const opts = { ...DEFAULT_DESIGN, ...userOptions };
      const qr = this.getMatrix(text, opts.ecc);
      const moduleCount = qr.getModuleCount();
      const margin = Math.max(0, parseInt(opts.margin, 10));
      const totalModules = moduleCount + margin * 2;
      const size = Math.max(128, parseInt(opts.size, 10));

      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext("2d");
      ctx.clearRect(0, 0, size, size);

      const cell = size / totalModules;
      const qrOffset = margin * cell;
      const hasLogo = Boolean(opts.logoSrc);

      // 1. Draw Background
      if (!opts.transparentBg) {
        ctx.fillStyle = opts.bgColor;
        ctx.fillRect(0, 0, size, size);
      }

      // 2. Prepare Fg Styles
      const fgStyle = opts.gradientType !== "none"
        ? this.createCanvasGradient(ctx, size, size, opts.gradientType, opts.fgColor, opts.gradientColor2, opts.gradientAngle)
        : opts.fgColor;

      const eyeOuterStyle = opts.eyeOuterColor || fgStyle;
      const eyeInnerStyle = opts.eyeInnerColor || fgStyle;

      // 3. Effects Setup
      ctx.save();
      if (opts.effect === "shadow") {
        ctx.shadowColor = opts.effectColor || "rgba(0,0,0,0.35)";
        ctx.shadowBlur = cell * 1.2;
        ctx.shadowOffsetX = cell * 0.4;
        ctx.shadowOffsetY = cell * 0.4;
      } else if (opts.effect === "glow") {
        ctx.shadowColor = opts.effectColor || "rgba(99,102,241,0.5)";
        ctx.shadowBlur = cell * 1.5;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 0;
      }

      // 4. Draw Data Modules (Skip Eyes and Logo Zone)
      ctx.fillStyle = fgStyle;
      for (let r = 0; r < moduleCount; r++) {
        for (let c = 0; c < moduleCount; c++) {
          const eyeInfo = this.getEyeLocation(r, c, moduleCount);
          if (eyeInfo.isEye) continue;

          if (this.isInLogoZone(r, c, moduleCount, hasLogo, opts.logoSize, opts.logoPadding)) {
            continue;
          }

          if (qr.isDark(r, c)) {
            const x = qrOffset + c * cell;
            const y = qrOffset + r * cell;
            this.drawModuleShape(ctx, x, y, cell, opts.moduleStyle);
          }
        }
      }
      ctx.restore();

      // 5. Draw Finder Pattern Eyes
      this.drawEyePattern(ctx, qrOffset, 0, 0, cell, opts.eyeOuterStyle, opts.eyeInnerStyle, eyeOuterStyle, eyeInnerStyle, opts.bgColor);
      this.drawEyePattern(ctx, qrOffset, 0, moduleCount - 7, cell, opts.eyeOuterStyle, opts.eyeInnerStyle, eyeOuterStyle, eyeInnerStyle, opts.bgColor);
      this.drawEyePattern(ctx, qrOffset, moduleCount - 7, 0, cell, opts.eyeOuterStyle, opts.eyeInnerStyle, eyeOuterStyle, eyeInnerStyle, opts.bgColor);

      // 6. Draw Center Logo if provided
      if (hasLogo) {
        await this.drawLogo(ctx, size, opts);
      }

      // 7. Outer soft border effect if requested
      if (opts.effect === "border") {
        ctx.strokeStyle = opts.effectColor || opts.fgColor;
        ctx.lineWidth = Math.max(2, cell * 0.4);
        ctx.strokeRect(cell * 0.5, cell * 0.5, size - cell, size - cell);
      }

      return {
        moduleCount,
        size,
        scannability: QRUtils.evaluateScannability({
          fgColor: opts.fgColor,
          bgColor: opts.bgColor,
          transparentBg: opts.transparentBg,
          hasLogo,
          logoSizeRatio: opts.logoSize,
          eccLevel: opts.ecc,
          margin
        })
      };
    }

    /**
     * Draw individual module shape
     */
    drawModuleShape(ctx, x, y, size, style) {
      const pad = size * 0.05;
      const w = size - pad * 2;
      const h = size - pad * 2;
      const px = x + pad;
      const py = y + pad;

      ctx.beginPath();
      switch (style) {
        case "dots":
          ctx.arc(x + size / 2, y + size / 2, w / 2, 0, Math.PI * 2);
          ctx.fill();
          break;

        case "rounded":
          const rad = w * 0.35;
          ctx.roundRect ? ctx.roundRect(px, py, w, h, rad) : this.legacyRoundRect(ctx, px, py, w, h, rad);
          ctx.fill();
          break;

        case "extra-rounded":
          const extraRad = w * 0.5;
          ctx.roundRect ? ctx.roundRect(px, py, w, h, extraRad) : this.legacyRoundRect(ctx, px, py, w, h, extraRad);
          ctx.fill();
          break;

        case "classy":
          // Elegant diamond module
          ctx.moveTo(x + size / 2, py);
          ctx.lineTo(px + w, y + size / 2);
          ctx.lineTo(x + size / 2, py + h);
          ctx.lineTo(px, y + size / 2);
          ctx.closePath();
          ctx.fill();
          break;

        case "square":
        default:
          ctx.fillRect(x, y, size + 0.3, size + 0.3); // slight overlap avoids canvas subpixel gaps
          break;
      }
    }

    /**
     * Legacy roundRect polyfill
     */
    legacyRoundRect(ctx, x, y, w, h, r) {
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + w - r, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + r);
      ctx.lineTo(x + w, y + h - r);
      ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      ctx.lineTo(x + r, y + h);
      ctx.quadraticCurveTo(x, y + h, x, y + h - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
    }

    /**
     * Draw a full 7x7 Finder Pattern Eye (Outer Frame + Inner Core)
     */
    drawEyePattern(ctx, offset, row, col, cell, outerStyle, innerStyle, outerColor, innerColor, bgColor) {
      const eyeX = offset + col * cell;
      const eyeY = offset + row * cell;
      const eyeSize = 7 * cell;

      // 1. Draw Outer Ring (7x7 with 5x5 cutout)
      ctx.fillStyle = outerColor;
      ctx.beginPath();
      switch (outerStyle) {
        case "circle":
          ctx.arc(eyeX + eyeSize / 2, eyeY + eyeSize / 2, eyeSize / 2, 0, Math.PI * 2);
          ctx.fill();
          break;

        case "rounded":
          ctx.roundRect ? ctx.roundRect(eyeX, eyeY, eyeSize, eyeSize, eyeSize * 0.3) : this.legacyRoundRect(ctx, eyeX, eyeY, eyeSize, eyeSize, eyeSize * 0.3);
          ctx.fill();
          break;

        case "leaf":
          ctx.moveTo(eyeX + eyeSize * 0.4, eyeY);
          ctx.lineTo(eyeX + eyeSize, eyeY);
          ctx.lineTo(eyeX + eyeSize, eyeY + eyeSize * 0.6);
          ctx.quadraticCurveTo(eyeX + eyeSize, eyeY + eyeSize, eyeX + eyeSize * 0.6, eyeY + eyeSize);
          ctx.lineTo(eyeX, eyeY + eyeSize);
          ctx.lineTo(eyeX, eyeY + eyeSize * 0.4);
          ctx.quadraticCurveTo(eyeX, eyeY, eyeX + eyeSize * 0.4, eyeY);
          ctx.fill();
          break;

        case "shield":
          ctx.moveTo(eyeX + eyeSize / 2, eyeY);
          ctx.lineTo(eyeX + eyeSize, eyeY + eyeSize * 0.25);
          ctx.lineTo(eyeX + eyeSize * 0.8, eyeY + eyeSize);
          ctx.lineTo(eyeX + eyeSize * 0.2, eyeY + eyeSize);
          ctx.lineTo(eyeX, eyeY + eyeSize * 0.25);
          ctx.closePath();
          ctx.fill();
          break;

        case "square":
        default:
          ctx.fillRect(eyeX, eyeY, eyeSize, eyeSize);
          break;
      }

      // Cut out inner 5x5 area
      const innerCutX = eyeX + cell;
      const innerCutY = eyeY + cell;
      const innerCutSize = 5 * cell;

      ctx.fillStyle = bgColor || "#ffffff";
      ctx.beginPath();
      if (outerStyle === "circle") {
        ctx.arc(innerCutX + innerCutSize / 2, innerCutY + innerCutSize / 2, innerCutSize / 2, 0, Math.PI * 2);
      } else if (outerStyle === "rounded" || outerStyle === "leaf") {
        ctx.roundRect ? ctx.roundRect(innerCutX, innerCutY, innerCutSize, innerCutSize, innerCutSize * 0.25) : this.legacyRoundRect(ctx, innerCutX, innerCutY, innerCutSize, innerCutSize, innerCutSize * 0.25);
      } else {
        ctx.rect(innerCutX, innerCutY, innerCutSize, innerCutSize);
      }
      ctx.fill();

      // 2. Draw Center Core (3x3)
      const coreX = eyeX + 2 * cell;
      const coreY = eyeY + 2 * cell;
      const coreSize = 3 * cell;

      ctx.fillStyle = innerColor;
      ctx.beginPath();
      switch (innerStyle) {
        case "dot":
          ctx.arc(coreX + coreSize / 2, coreY + coreSize / 2, coreSize / 2, 0, Math.PI * 2);
          ctx.fill();
          break;

        case "rounded":
          ctx.roundRect ? ctx.roundRect(coreX, coreY, coreSize, coreSize, coreSize * 0.35) : this.legacyRoundRect(ctx, coreX, coreY, coreSize, coreSize, coreSize * 0.35);
          ctx.fill();
          break;

        case "diamond":
          ctx.moveTo(coreX + coreSize / 2, coreY);
          ctx.lineTo(coreX + coreSize, coreY + coreSize / 2);
          ctx.lineTo(coreX + coreSize / 2, coreY + coreSize);
          ctx.lineTo(coreX, coreY + coreSize / 2);
          ctx.closePath();
          ctx.fill();
          break;

        case "star":
          this.drawStar(ctx, coreX + coreSize / 2, coreY + coreSize / 2, 4, coreSize / 2, coreSize / 4);
          ctx.fill();
          break;

        case "square":
        default:
          ctx.fillRect(coreX, coreY, coreSize, coreSize);
          break;
      }
    }

    drawStar(ctx, cx, cy, spikes, outerRadius, innerRadius) {
      let rot = (Math.PI / 2) * 3;
      let x = cx;
      let y = cy;
      const step = Math.PI / spikes;

      ctx.moveTo(cx, cy - outerRadius);
      for (let i = 0; i < spikes; i++) {
        x = cx + Math.cos(rot) * outerRadius;
        y = cy + Math.sin(rot) * outerRadius;
        ctx.lineTo(x, y);
        rot += step;

        x = cx + Math.cos(rot) * innerRadius;
        y = cy + Math.sin(rot) * innerRadius;
        ctx.lineTo(x, y);
        rot += step;
      }
      ctx.lineTo(cx, cy - outerRadius);
      ctx.closePath();
    }

    /**
     * Draw center logo onto Canvas
     */
    drawLogo(ctx, canvasSize, opts) {
      return new Promise((resolve) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
          const logoPixelSize = canvasSize * opts.logoSize;
          const x = (canvasSize - logoPixelSize) / 2;
          const y = (canvasSize - logoPixelSize) / 2;
          const bgPadding = logoPixelSize * 0.12;

          // 1. Draw logo background badge if selected
          if (opts.logoBgShape !== "none") {
            ctx.save();
            ctx.fillStyle = opts.logoBgColor || "#ffffff";
            const bgX = x - bgPadding;
            const bgY = y - bgPadding;
            const bgSize = logoPixelSize + bgPadding * 2;

            ctx.beginPath();
            if (opts.logoBgShape === "circle") {
              ctx.arc(canvasSize / 2, canvasSize / 2, bgSize / 2, 0, Math.PI * 2);
            } else if (opts.logoBgShape === "rounded") {
              ctx.roundRect ? ctx.roundRect(bgX, bgY, bgSize, bgSize, bgSize * 0.25) : this.legacyRoundRect(ctx, bgX, bgY, bgSize, bgSize, bgSize * 0.25);
            } else {
              ctx.rect(bgX, bgY, bgSize, bgSize);
            }
            ctx.fill();
            ctx.restore();
          }

          // 2. Draw centered image with high smoothing
          ctx.save();
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = "high";
          ctx.drawImage(img, x, y, logoPixelSize, logoPixelSize);
          ctx.restore();
          resolve();
        };
        img.onerror = () => {
          console.warn("Logo failed to load");
          resolve();
        };
        img.src = opts.logoSrc;
      });
    }

    /**
     * Generate Scalable Vector SVG
     */
    renderToSVG(text, userOptions = {}) {
      const opts = { ...DEFAULT_DESIGN, ...userOptions };
      const qr = this.getMatrix(text, opts.ecc);
      const moduleCount = qr.getModuleCount();
      const margin = Math.max(0, parseInt(opts.margin, 10));
      const totalModules = moduleCount + margin * 2;
      const size = 512;
      const cell = size / totalModules;
      const qrOffset = margin * cell;
      const hasLogo = Boolean(opts.logoSrc);

      let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">\n`;

      // Defs for Gradients
      svg += `  <defs>\n`;
      let fillRef = opts.fgColor;
      if (opts.gradientType === "linear") {
        fillRef = "url(#qr-linear-grad)";
        const rad = (opts.gradientAngle * Math.PI) / 180;
        const x1 = Math.round(50 - Math.cos(rad) * 50);
        const y1 = Math.round(50 - Math.sin(rad) * 50);
        const x2 = Math.round(50 + Math.cos(rad) * 50);
        const y2 = Math.round(50 + Math.sin(rad) * 50);
        svg += `    <linearGradient id="qr-linear-grad" x1="${x1}%" y1="${y1}%" x2="${x2}%" y2="${y2}%">\n`;
        svg += `      <stop offset="0%" stop-color="${opts.fgColor}"/>\n`;
        svg += `      <stop offset="100%" stop-color="${opts.gradientColor2}"/>\n`;
        svg += `    </linearGradient>\n`;
      } else if (opts.gradientType === "radial") {
        fillRef = "url(#qr-radial-grad)";
        svg += `    <radialGradient id="qr-radial-grad" cx="50%" cy="50%" r="50%">\n`;
        svg += `      <stop offset="0%" stop-color="${opts.fgColor}"/>\n`;
        svg += `      <stop offset="100%" stop-color="${opts.gradientColor2}"/>\n`;
        svg += `    </radialGradient>\n`;
      }
      svg += `  </defs>\n`;

      // Background
      if (!opts.transparentBg) {
        svg += `  <rect width="${size}" height="${size}" fill="${opts.bgColor}"/>\n`;
      }

      // Modules Path Builder
      let modulesSvg = `  <g fill="${fillRef}">\n`;
      for (let r = 0; r < moduleCount; r++) {
        for (let c = 0; c < moduleCount; c++) {
          const eye = this.getEyeLocation(r, c, moduleCount);
          if (eye.isEye) continue;
          if (this.isInLogoZone(r, c, moduleCount, hasLogo, opts.logoSize, opts.logoPadding)) continue;

          if (qr.isDark(r, c)) {
            const x = (qrOffset + c * cell).toFixed(2);
            const y = (qrOffset + r * cell).toFixed(2);
            const w = cell.toFixed(2);

            if (opts.moduleStyle === "dots") {
              const cx = (qrOffset + c * cell + cell / 2).toFixed(2);
              const cy = (qrOffset + r * cell + cell / 2).toFixed(2);
              const cr = (cell * 0.44).toFixed(2);
              modulesSvg += `    <circle cx="${cx}" cy="${cy}" r="${cr}"/>\n`;
            } else if (opts.moduleStyle === "rounded" || opts.moduleStyle === "extra-rounded") {
              const rx = (cell * (opts.moduleStyle === "extra-rounded" ? 0.5 : 0.3)).toFixed(2);
              modulesSvg += `    <rect x="${x}" y="${y}" width="${w}" height="${w}" rx="${rx}"/>\n`;
            } else {
              modulesSvg += `    <rect x="${x}" y="${y}" width="${w}" height="${w}"/>\n`;
            }
          }
        }
      }
      modulesSvg += `  </g>\n`;
      svg += modulesSvg;

      // Draw SVG Eyes
      const eyeOuterColor = opts.eyeOuterColor || fillRef;
      const eyeInnerColor = opts.eyeInnerColor || fillRef;
      const renderSvgEye = (originR, originC) => {
        const eyeX = (qrOffset + originC * cell).toFixed(2);
        const eyeY = (qrOffset + originR * cell).toFixed(2);
        const eyeSize = (7 * cell).toFixed(2);
        const innerCutX = (qrOffset + (originC + 1) * cell).toFixed(2);
        const innerCutY = (qrOffset + (originR + 1) * cell).toFixed(2);
        const innerCutSize = (5 * cell).toFixed(2);
        const coreX = (qrOffset + (originC + 2) * cell).toFixed(2);
        const coreY = (qrOffset + (originR + 2) * cell).toFixed(2);
        const coreSize = (3 * cell).toFixed(2);

        let eyeStr = `  <!-- Eye at [${originR}, ${originC}] -->\n  <g>\n`;
        // Outer ring
        if (opts.eyeOuterStyle === "circle") {
          const cx = (qrOffset + (originC + 3.5) * cell).toFixed(2);
          const cy = (qrOffset + (originR + 3.5) * cell).toFixed(2);
          eyeStr += `    <circle cx="${cx}" cy="${cy}" r="${(7 * cell / 2).toFixed(2)}" fill="${eyeOuterColor}"/>\n`;
          eyeStr += `    <circle cx="${cx}" cy="${cy}" r="${(5 * cell / 2).toFixed(2)}" fill="${opts.bgColor || "#ffffff"}"/>\n`;
        } else if (opts.eyeOuterStyle === "rounded") {
          eyeStr += `    <rect x="${eyeX}" y="${eyeY}" width="${eyeSize}" height="${eyeSize}" rx="${(eyeSize * 0.28).toFixed(2)}" fill="${eyeOuterColor}"/>\n`;
          eyeStr += `    <rect x="${innerCutX}" y="${innerCutY}" width="${innerCutSize}" height="${innerCutSize}" rx="${(innerCutSize * 0.22).toFixed(2)}" fill="${opts.bgColor || "#ffffff"}"/>\n`;
        } else {
          eyeStr += `    <rect x="${eyeX}" y="${eyeY}" width="${eyeSize}" height="${eyeSize}" fill="${eyeOuterColor}"/>\n`;
          eyeStr += `    <rect x="${innerCutX}" y="${innerCutY}" width="${innerCutSize}" height="${innerCutSize}" fill="${opts.bgColor || "#ffffff"}"/>\n`;
        }

        // Inner Core
        if (opts.eyeInnerStyle === "dot") {
          const cx = (qrOffset + (originC + 3.5) * cell).toFixed(2);
          const cy = (qrOffset + (originR + 3.5) * cell).toFixed(2);
          eyeStr += `    <circle cx="${cx}" cy="${cy}" r="${(3 * cell / 2).toFixed(2)}" fill="${eyeInnerColor}"/>\n`;
        } else if (opts.eyeInnerStyle === "rounded") {
          eyeStr += `    <rect x="${coreX}" y="${coreY}" width="${coreSize}" height="${coreSize}" rx="${(coreSize * 0.35).toFixed(2)}" fill="${eyeInnerColor}"/>\n`;
        } else {
          eyeStr += `    <rect x="${coreX}" y="${coreY}" width="${coreSize}" height="${coreSize}" fill="${eyeInnerColor}"/>\n`;
        }
        eyeStr += `  </g>\n`;
        return eyeStr;
      };

      svg += renderSvgEye(0, 0);
      svg += renderSvgEye(0, moduleCount - 7);
      svg += renderSvgEye(moduleCount - 7, 0);

      // Logo in SVG
      if (hasLogo) {
        const logoPx = size * opts.logoSize;
        const x = (size - logoPx) / 2;
        const y = (size - logoPx) / 2;
        const pad = logoPx * 0.12;

        if (opts.logoBgShape !== "none") {
          if (opts.logoBgShape === "circle") {
            svg += `  <circle cx="${size / 2}" cy="${size / 2}" r="${((logoPx + pad * 2) / 2).toFixed(2)}" fill="${opts.logoBgColor || "#ffffff"}"/>\n`;
          } else {
            svg += `  <rect x="${(x - pad).toFixed(2)}" y="${(y - pad).toFixed(2)}" width="${(logoPx + pad * 2).toFixed(2)}" height="${(logoPx + pad * 2).toFixed(2)}" rx="${opts.logoBgShape === "rounded" ? (logoPx * 0.25).toFixed(2) : 0}" fill="${opts.logoBgColor || "#ffffff"}"/>\n`;
          }
        }
        svg += `  <image href="${opts.logoSrc}" x="${x.toFixed(2)}" y="${y.toFixed(2)}" width="${logoPx.toFixed(2)}" height="${logoPx.toFixed(2)}"/>\n`;
      }

      svg += `</svg>`;
      return svg;
    }
  }

  global.QREngine = new QREngine();
  global.DEFAULT_QR_DESIGN = DEFAULT_DESIGN;

})(typeof window !== "undefined" ? window : global);
