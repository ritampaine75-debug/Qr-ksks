/**
 * QR STUDIO - TEMPLATES CONTROLLER
 * 13+ Curated Professional Design Presets with 1-Click Instant Loading into Editor
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  const TEMPLATES = [
    {
      id: "minimal-black",
      name: "Minimal Black",
      category: "minimal",
      desc: "Ultra clean monochrome design with maximum universal scan reliability.",
      design: {
        fgColor: "#000000",
        bgColor: "#ffffff",
        transparentBg: false,
        gradientType: "none",
        moduleStyle: "square",
        eyeOuterStyle: "square",
        eyeInnerStyle: "square",
        margin: 2,
        ecc: "M"
      }
    },
    {
      id: "minimal-white",
      name: "Minimal Dark Mode",
      category: "minimal",
      desc: "Crisp white modules on deep onyx background for modern dark interfaces.",
      design: {
        fgColor: "#ffffff",
        bgColor: "#0f172a",
        transparentBg: false,
        gradientType: "none",
        moduleStyle: "square",
        eyeOuterStyle: "rounded",
        eyeInnerStyle: "rounded",
        margin: 2,
        ecc: "M"
      }
    },
    {
      id: "business-executive",
      name: "Business Executive",
      category: "business",
      desc: "Navy blue tones with rounded eye frames, tailored for professional corporate branding.",
      design: {
        fgColor: "#1e3a8a",
        bgColor: "#ffffff",
        transparentBg: false,
        gradientType: "linear",
        gradientColor2: "#0284c7",
        gradientAngle: 45,
        moduleStyle: "rounded",
        eyeOuterStyle: "rounded",
        eyeInnerStyle: "square",
        margin: 2,
        ecc: "Q"
      }
    },
    {
      id: "restaurant-menu",
      name: "Restaurant Menu",
      category: "creative",
      desc: "Warm terracotta and amber palette with soft pill modules for dining menus.",
      design: {
        fgColor: "#9a3412",
        bgColor: "#fffbeb",
        transparentBg: false,
        gradientType: "none",
        moduleStyle: "rounded",
        eyeOuterStyle: "leaf",
        eyeInnerStyle: "rounded",
        margin: 2,
        ecc: "M"
      }
    },
    {
      id: "social-media",
      name: "Social Media Gradient",
      category: "social",
      desc: "Vibrant violet and magenta sunset gradient with circular dots.",
      design: {
        fgColor: "#8b5cf6",
        bgColor: "#ffffff",
        transparentBg: false,
        gradientType: "linear",
        gradientColor2: "#ec4899",
        gradientAngle: 60,
        moduleStyle: "dots",
        eyeOuterStyle: "circle",
        eyeInnerStyle: "dot",
        logoSrc: "assets/logos/logo-instagram.svg",
        logoSize: 0.22,
        logoBgShape: "circle",
        logoBgColor: "#ffffff",
        margin: 2,
        ecc: "H"
      }
    },
    {
      id: "fintech-payment",
      name: "Fintech & Payment",
      category: "business",
      desc: "Emerald green and dark teal with high security error correction.",
      design: {
        fgColor: "#059669",
        bgColor: "#ffffff",
        transparentBg: false,
        gradientType: "linear",
        gradientColor2: "#0d9488",
        gradientAngle: 30,
        moduleStyle: "square",
        eyeOuterStyle: "shield",
        eyeInnerStyle: "square",
        logoSrc: "assets/logos/logo-shield.svg",
        logoSize: 0.2,
        logoBgShape: "rounded",
        logoBgColor: "#ffffff",
        margin: 2,
        ecc: "H"
      }
    },
    {
      id: "wifi-connect",
      name: "Wi-Fi Connect",
      category: "creative",
      desc: "Cyan and electric blue tech aesthetic featuring centered Wi-Fi badge.",
      design: {
        fgColor: "#0284c7",
        bgColor: "#f0fdf4",
        transparentBg: false,
        gradientType: "linear",
        gradientColor2: "#059669",
        gradientAngle: 90,
        moduleStyle: "dots",
        eyeOuterStyle: "rounded",
        eyeInnerStyle: "dot",
        logoSrc: "assets/logos/logo-wifi.svg",
        logoSize: 0.22,
        logoBgShape: "circle",
        logoBgColor: "#ffffff",
        margin: 2,
        ecc: "H"
      }
    },
    {
      id: "luxury-gold",
      name: "Luxury VIP & Event",
      category: "creative",
      desc: "Champagne gold on rich obsidian with elegant classy diamond modules.",
      design: {
        fgColor: "#d97706",
        bgColor: "#111827",
        transparentBg: false,
        gradientType: "linear",
        gradientColor2: "#f59e0b",
        gradientAngle: 45,
        moduleStyle: "classy",
        eyeOuterStyle: "leaf",
        eyeInnerStyle: "diamond",
        logoSrc: "assets/logos/logo-star.svg",
        logoSize: 0.2,
        logoBgShape: "circle",
        logoBgColor: "#111827",
        margin: 2,
        ecc: "H"
      }
    },
    {
      id: "digital-vcard",
      name: "Digital Business Card",
      category: "business",
      desc: "Slate indigo and modern cobalt for personal networking and conferences.",
      design: {
        fgColor: "#4338ca",
        bgColor: "#ffffff",
        transparentBg: false,
        gradientType: "linear",
        gradientColor2: "#3b82f6",
        gradientAngle: 45,
        moduleStyle: "rounded",
        eyeOuterStyle: "rounded",
        eyeInnerStyle: "rounded",
        logoSrc: "assets/logos/logo-link.svg",
        logoSize: 0.2,
        logoBgShape: "rounded",
        logoBgColor: "#ffffff",
        margin: 2,
        ecc: "H"
      }
    },
    {
      id: "luxury-onyx",
      name: "Luxury Monochrome",
      category: "minimal",
      desc: "Precision onyx styling with diamond core eyes for luxury fashion and goods.",
      design: {
        fgColor: "#18181b",
        bgColor: "#ffffff",
        transparentBg: false,
        gradientType: "none",
        moduleStyle: "classy",
        eyeOuterStyle: "shield",
        eyeInnerStyle: "diamond",
        margin: 2,
        ecc: "Q"
      }
    },
    {
      id: "modern-sunset",
      name: "Sunset Coral",
      category: "creative",
      desc: "Warm radial gradient transitioning from vibrant coral to citrus orange.",
      design: {
        fgColor: "#f43f5e",
        bgColor: "#ffffff",
        transparentBg: false,
        gradientType: "radial",
        gradientColor2: "#fb923c",
        moduleStyle: "dots",
        eyeOuterStyle: "circle",
        eyeInnerStyle: "dot",
        margin: 2,
        ecc: "Q"
      }
    },
    {
      id: "soft-sage",
      name: "Soft Sage",
      category: "creative",
      desc: "Organic pastel tones with extra-rounded fluid pebble modules.",
      design: {
        fgColor: "#15803d",
        bgColor: "#f0fdf4",
        transparentBg: false,
        gradientType: "none",
        moduleStyle: "extra-rounded",
        eyeOuterStyle: "rounded",
        eyeInnerStyle: "dot",
        margin: 2,
        ecc: "M"
      }
    },
    {
      id: "corporate-trust",
      name: "Corporate Trust",
      category: "business",
      desc: "Deep cobalt precision modules engineered for banking, finance, and enterprise.",
      design: {
        fgColor: "#1d4ed8",
        bgColor: "#ffffff",
        transparentBg: false,
        gradientType: "none",
        moduleStyle: "square",
        eyeOuterStyle: "square",
        eyeInnerStyle: "square",
        margin: 3,
        ecc: "H"
      }
    }
  ];

  class QRTemplatesController {
    constructor() {
      this.activeCategory = "all";
    }

    init() {
      this.renderFilterTabs();
      this.renderTemplates();
    }

    renderFilterTabs() {
      const container = document.getElementById("templates-filter-tabs");
      if (!container) return;

      const categories = [
        { id: "all", name: "All Presets" },
        { id: "minimal", name: "Minimal" },
        { id: "business", name: "Business & Corporate" },
        { id: "creative", name: "Creative & Menus" },
        { id: "social", name: "Social & Media" }
      ];

      container.innerHTML = categories.map((c) => `
        <button class="btn btn-secondary btn-sm filter-tab-btn ${c.id === this.activeCategory ? "active btn-primary" : ""}" data-category="${c.id}">
          ${c.name}
        </button>
      `).join("");

      container.querySelectorAll(".filter-tab-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          this.activeCategory = btn.dataset.category;
          container.querySelectorAll(".filter-tab-btn").forEach((b) => {
            b.classList.remove("active", "btn-primary");
            b.classList.add("btn-secondary");
          });
          btn.classList.add("active", "btn-primary");
          btn.classList.remove("btn-secondary");
          this.renderTemplates();
        });
      });
    }

    async renderTemplates() {
      const grid = document.getElementById("templates-grid");
      if (!grid) return;

      const filtered = this.activeCategory === "all"
        ? TEMPLATES
        : TEMPLATES.filter((t) => t.category === this.activeCategory);

      grid.innerHTML = filtered.map((t) => `
        <div class="template-card" data-template-id="${t.id}">
          <div class="template-preview-wrap">
            <canvas id="template-canvas-${t.id}" class="template-preview-img" width="160" height="160"></canvas>
          </div>
          <div class="template-content">
            <h3 class="template-title">${t.name}</h3>
            <p class="template-desc">${t.desc}</p>
            <div style="margin-top: auto;">
              <button class="btn btn-primary btn-sm btn-use-template" data-template-id="${t.id}" style="width: 100%;">
                Use Template in Studio
              </button>
            </div>
          </div>
        </div>
      `).join("");

      // Render previews for each template canvas
      for (const t of filtered) {
        const c = document.getElementById(`template-canvas-${t.id}`);
        if (c) {
          QREngine.renderToCanvas(c, "https://qrstudio.app", {
            ...t.design,
            size: 160
          });
        }
      }

      // Attach button clicks
      grid.querySelectorAll(".btn-use-template").forEach((btn) => {
        btn.addEventListener("click", () => {
          const tId = btn.dataset.templateId;
          const template = TEMPLATES.find((item) => item.id === tId);
          if (template) {
            QRStorage.setDraft({
              payload: "https://qrstudio.app",
              design: template.design
            });
            QRUI.showToast(`Loaded "${template.name}" into Editor!`, "success");
            if (global.QRRouter) {
              QRRouter.navigate("/editor");
            } else {
              window.location.href = "editor.html";
            }
          }
        });
      });
    }
  }

  global.QRTemplates = new QRTemplatesController();
  global.PRESET_TEMPLATES = TEMPLATES;

})(typeof window !== "undefined" ? window : global);
