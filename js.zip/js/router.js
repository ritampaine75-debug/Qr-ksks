/**
 * QR STUDIO - CLIENT-SIDE ROUTER & CLEAN NAVIGATION
 * Handles clean URLs (/generator, /editor, /scanner, /templates, /history, /settings, /about)
 * Supports History API, static host fallbacks (GitHub Pages 404, Netlify, Vercel), and local file:// access
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  const ROUTES = {
    "/": { title: "QR Studio — All-in-One QR Code Studio", pageId: "page-home", file: "index.html" },
    "/generator": { title: "QR Generator — QR Studio", pageId: "page-generator", file: "generator.html" },
    "/editor": { title: "QR Design Studio & Editor — QR Studio", pageId: "page-editor", file: "editor.html" },
    "/scanner": { title: "QR Scanner & Decoder — QR Studio", pageId: "page-scanner", file: "scanner.html" },
    "/templates": { title: "QR Design Templates — QR Studio", pageId: "page-templates", file: "templates.html" },
    "/history": { title: "QR Code History — QR Studio", pageId: "page-history", file: "history.html" },
    "/settings": { title: "Settings & Preferences — QR Studio", pageId: "page-settings", file: "settings.html" },
    "/about": { title: "About QR Studio — Developed by Ritam", pageId: "page-about", file: "about.html" }
  };

  class Router {
    constructor() {
      this.currentRoute = "/";
      this.isSinglePageShell = false;
    }

    init() {
      // Check if we are running in SPA shell mode (index.html contains view containers)
      this.isSinglePageShell = Boolean(document.getElementById("page-generator"));

      // Check for GitHub Pages 404 redirect param: ?p=/generator
      const urlParams = new URLSearchParams(window.location.search);
      const redirectPath = urlParams.get("p");
      if (redirectPath && ROUTES[redirectPath]) {
        window.history.replaceState(null, "", redirectPath);
      }

      // Determine initial route from location.pathname
      this.resolveCurrentRoute();

      // Listen for browser Back/Forward
      window.addEventListener("popstate", () => {
        this.resolveCurrentRoute();
      });

      // Intercept internal link clicks for smooth clean navigation
      document.addEventListener("click", (e) => {
        const link = e.target.closest("a");
        if (!link) return;

        const href = link.getAttribute("href");
        if (!href || href.startsWith("http") || href.startsWith("//") || href.startsWith("mailto:") || href.startsWith("tel:") || href.startsWith("#")) {
          return;
        }

        // Clean link target
        let targetRoute = href.replace(/\.html$/, "");
        if (targetRoute === "" || targetRoute === "index") targetRoute = "/";
        if (!targetRoute.startsWith("/")) targetRoute = "/" + targetRoute;

        if (ROUTES[targetRoute]) {
          e.preventDefault();
          this.navigate(targetRoute);
        }
      });
    }

    resolveCurrentRoute() {
      let path = window.location.pathname;

      // Normalize path
      let clean = path.replace(/\/index\.html$/, "/").replace(/\.html$/, "");
      // Handle subfolder deployments (e.g. /QR-Studio/)
      const segments = clean.split("/").filter(Boolean);
      const lastSegment = segments[segments.length - 1];

      let matchedRoute = "/";
      if (lastSegment && ROUTES["/" + lastSegment]) {
        matchedRoute = "/" + lastSegment;
      } else if (ROUTES[clean]) {
        matchedRoute = clean;
      }

      this.currentRoute = matchedRoute;
      this.updateActiveNav(matchedRoute);

      if (this.isSinglePageShell) {
        this.renderView(matchedRoute);
      }
    }

    navigate(routePath) {
      if (!ROUTES[routePath]) routePath = "/";
      const route = ROUTES[routePath];

      // Update Document Title
      document.title = route.title;

      // If running via file:// or non-SPA shell, navigate directly to file
      if (window.location.protocol === "file:" || !this.isSinglePageShell) {
        const targetFile = route.file;
        if (!window.location.pathname.endsWith(targetFile)) {
          window.location.href = targetFile;
        }
        return;
      }

      // History API clean route update
      try {
        window.history.pushState(null, route.title, routePath);
      } catch (err) {
        // Fallback
      }

      this.currentRoute = routePath;
      this.updateActiveNav(routePath);
      this.renderView(routePath);
    }

    updateActiveNav(routePath) {
      document.querySelectorAll(".nav-link, .nav-mobile-item").forEach((el) => {
        const href = el.getAttribute("href") || "";
        const cleanHref = href.replace(/\.html$/, "").replace(/^\/?/, "/");
        const isMatch = cleanHref === routePath || (routePath === "/" && (cleanHref === "/" || cleanHref === "/index"));
        el.classList.toggle("active", isMatch);
      });
    }

    renderView(routePath) {
      // Hide all page containers
      document.querySelectorAll(".page-view").forEach((view) => {
        view.style.display = "none";
      });

      const route = ROUTES[routePath] || ROUTES["/"];
      const targetEl = document.getElementById(route.pageId);
      if (targetEl) {
        targetEl.style.display = "block";
        window.scrollTo({ top: 0, behavior: "smooth" });

        // Trigger component initializers when their view is activated
        if (routePath === "/generator" && global.QRGenerator) {
          global.QRGenerator.init();
        } else if (routePath === "/editor" && global.QREditor) {
          global.QREditor.init();
        } else if (routePath === "/scanner" && global.QRScanner) {
          global.QRScanner.init();
        } else if (routePath === "/templates" && global.QRTemplates) {
          global.QRTemplates.init();
        } else if (routePath === "/history" && global.QRHistory) {
          global.QRHistory.init();
        } else if (routePath === "/settings" && global.QRSettings) {
          global.QRSettings.init();
        }
      }
    }
  }

  global.QRRouter = new Router();
  global.APP_ROUTES = ROUTES;

})(typeof window !== "undefined" ? window : global);
