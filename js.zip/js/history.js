/**
 * QR STUDIO - HISTORY CONTROLLER
 * Local Storage History, Search & Filter, Reopen, Quick Download, Duplicate, and Delete
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  class QRHistoryController {
    constructor() {
      this.searchQuery = "";
    }

    init() {
      this.bindSearch();
      this.bindClearAll();
      this.render();
    }

    bindSearch() {
      const searchInput = document.getElementById("history-search-input");
      if (searchInput) {
        searchInput.addEventListener("input", (e) => {
          this.searchQuery = e.target.value.toLowerCase().trim();
          this.render();
        });
      }
    }

    bindClearAll() {
      const clearBtn = document.getElementById("btn-clear-all-history");
      if (clearBtn) {
        clearBtn.addEventListener("click", async () => {
          const items = QRStorage.getHistory();
          if (items.length === 0) {
            QRUI.showToast("History is already empty.", "info");
            return;
          }
          const confirmed = await QRUI.confirm(
            "Clear History?",
            `Are you sure you want to permanently delete all ${items.length} saved QR codes from local storage? This action cannot be undone.`,
            "Clear History",
            true
          );
          if (confirmed) {
            QRStorage.clearHistory();
            this.render();
            QRUI.showToast("All QR history cleared.", "success");
          }
        });
      }
    }

    render() {
      const container = document.getElementById("history-list-grid");
      const emptyState = document.getElementById("history-empty-state");
      const countEl = document.getElementById("history-count-badge");
      if (!container) return;

      const allItems = QRStorage.getHistory();
      if (countEl) countEl.textContent = `${allItems.length} codes`;

      const filtered = this.searchQuery
        ? allItems.filter((item) =>
            (item.title && item.title.toLowerCase().includes(this.searchQuery)) ||
            (item.data && item.data.toLowerCase().includes(this.searchQuery)) ||
            (item.type && item.type.toLowerCase().includes(this.searchQuery))
          )
        : allItems;

      if (filtered.length === 0) {
        container.innerHTML = "";
        if (emptyState) emptyState.style.display = "flex";
        return;
      }

      if (emptyState) emptyState.style.display = "none";

      container.innerHTML = filtered.map((item) => {
        const dateStr = item.timestamp ? new Date(item.timestamp).toLocaleDateString(undefined, {
          month: "short",
          day: "numeric",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit"
        }) : "Recent";

        return `
          <div class="history-card" data-id="${item.id}">
            <img class="history-thumb" src="${item.thumbnail || "assets/icons/qrcode.svg"}" alt="QR Thumbnail">
            <div class="history-info">
              <div class="flex items-center gap-2">
                <span class="history-title">${QRUtils.escapeHtml(item.title)}</span>
                <span class="badge badge-neutral text-xs">${QRUtils.escapeHtml(item.type || "QR")}</span>
              </div>
              <div class="history-data" title="${QRUtils.escapeHtml(item.data)}">${QRUtils.escapeHtml(item.data)}</div>
              <div class="history-date">${dateStr}</div>
            </div>
            <div class="history-actions">
              <button class="btn btn-secondary btn-icon btn-sm btn-history-edit" data-id="${item.id}" title="Edit in Studio" aria-label="Edit in Studio">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
              </button>
              <button class="btn btn-secondary btn-icon btn-sm btn-history-download" data-id="${item.id}" title="Download PNG" aria-label="Download PNG">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              </button>
              <button class="btn btn-ghost btn-icon btn-sm btn-history-delete text-danger" data-id="${item.id}" title="Delete" aria-label="Delete">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
              </button>
            </div>
          </div>
        `;
      }).join("");

      // Action Handlers
      container.querySelectorAll(".btn-history-edit").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.dataset.id;
          const item = allItems.find((i) => i.id === id);
          if (item) {
            QRStorage.setDraft({
              payload: item.data,
              design: item.design || { ...DEFAULT_QR_DESIGN }
            });
            if (global.QRRouter) {
              QRRouter.navigate("/editor");
            } else {
              window.location.href = "editor.html";
            }
          }
        });
      });

      container.querySelectorAll(".btn-history-download").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.dataset.id;
          const item = allItems.find((i) => i.id === id);
          if (item && item.thumbnail) {
            QRUtils.triggerDownload(item.thumbnail, `qr-studio-saved-${Date.now()}.png`);
            QRUI.showToast("Downloaded saved QR image!", "success");
          } else if (item && item.data) {
            // Re-render
            const temp = document.createElement("canvas");
            QREngine.renderToCanvas(temp, item.data, item.design || DEFAULT_QR_DESIGN).then(() => {
              const url = temp.toDataURL("image/png");
              QRUtils.triggerDownload(url, `qr-studio-saved-${Date.now()}.png`);
              QRUI.showToast("Downloaded saved QR image!", "success");
            });
          }
        });
      });

      container.querySelectorAll(".btn-history-delete").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.dataset.id;
          QRStorage.deleteHistoryItem(id);
          this.render();
          QRUI.showToast("Item removed from history.", "info");
        });
      });
    }
  }

  global.QRHistory = new QRHistoryController();
})(typeof window !== "undefined" ? window : global);
