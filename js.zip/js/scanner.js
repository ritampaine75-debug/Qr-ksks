/**
 * QR STUDIO - SCANNER CONTROLLER
 * Camera Scanner, Image File Detection, Security Verification, and Recreate & Download Workflow
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  class QRScannerController {
    constructor() {
      this.activeTab = "camera"; // 'camera' or 'upload'
      this.videoStream = null;
      this.scanning = false;
      this.facingMode = "environment";
      this.torchOn = false;
      this.barcodeDetector = null;
      this.lastScanResult = null;
      this.animFrameId = null;
    }

    async init() {
      this.bindTabEvents();
      this.bindUploadEvents();
      this.bindActionEvents();

      // Check if native BarcodeDetector is supported
      if ("BarcodeDetector" in window) {
        try {
          const formats = await BarcodeDetector.getSupportedFormats();
          if (formats.includes("qr_code")) {
            this.barcodeDetector = new BarcodeDetector({ formats: ["qr_code"] });
          }
        } catch (e) {
          console.warn("BarcodeDetector initialization failed, using jsQR fallback", e);
        }
      }
    }

    bindTabEvents() {
      const tabCamera = document.getElementById("tab-scanner-camera");
      const tabUpload = document.getElementById("tab-scanner-upload");
      const viewCamera = document.getElementById("scanner-camera-view");
      const viewUpload = document.getElementById("scanner-upload-view");

      if (tabCamera && tabUpload) {
        tabCamera.addEventListener("click", () => {
          this.activeTab = "camera";
          tabCamera.classList.add("active");
          tabUpload.classList.remove("active");
          if (viewCamera) viewCamera.style.display = "block";
          if (viewUpload) viewUpload.style.display = "none";
          this.startCamera();
        });

        tabUpload.addEventListener("click", () => {
          this.activeTab = "upload";
          tabUpload.classList.add("active");
          tabCamera.classList.remove("active");
          if (viewUpload) viewUpload.style.display = "block";
          if (viewCamera) viewCamera.style.display = "none";
          this.stopCamera();
        });
      }

      // Camera Controls
      const startCamBtn = document.getElementById("btn-start-camera");
      if (startCamBtn) {
        startCamBtn.addEventListener("click", () => this.startCamera());
      }

      const flipBtn = document.getElementById("btn-flip-camera");
      if (flipBtn) {
        flipBtn.addEventListener("click", () => {
          this.facingMode = this.facingMode === "environment" ? "user" : "environment";
          this.startCamera();
        });
      }

      const torchBtn = document.getElementById("btn-toggle-torch");
      if (torchBtn) {
        torchBtn.addEventListener("click", () => this.toggleTorch());
      }
    }

    async startCamera() {
      this.stopCamera();
      const video = document.getElementById("scanner-video");
      const placeholder = document.getElementById("scanner-cam-placeholder");
      if (!video) return;

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: this.facingMode,
            width: { ideal: 1280 },
            height: { ideal: 720 }
          },
          audio: false
        });

        this.videoStream = stream;
        video.srcObject = stream;
        await video.play();

        this.scanning = true;
        if (placeholder) placeholder.style.display = "none";
        video.style.display = "block";

        const reticle = document.getElementById("scanner-reticle-box");
        if (reticle) reticle.style.display = "flex";

        this.runScanLoop();
      } catch (err) {
        console.error("Camera access error:", err);
        let msg = "Camera access denied. Please grant camera permission or upload an image file instead.";
        if (err.name === "NotFoundError" || err.name === "DevicesNotFoundError") {
          msg = "No camera found on your device. Please use the Upload Image tab.";
        }
        QRUI.showToast(msg, "warning", 4500);
      }
    }

    stopCamera() {
      this.scanning = false;
      if (this.animFrameId) {
        cancelAnimationFrame(this.animFrameId);
        this.animFrameId = null;
      }
      if (this.videoStream) {
        this.videoStream.getTracks().forEach((track) => track.stop());
        this.videoStream = null;
      }
      const video = document.getElementById("scanner-video");
      if (video) video.style.display = "none";
      const reticle = document.getElementById("scanner-reticle-box");
      if (reticle) reticle.style.display = "none";
      const placeholder = document.getElementById("scanner-cam-placeholder");
      if (placeholder) placeholder.style.display = "flex";
    }

    async toggleTorch() {
      if (!this.videoStream) return;
      const track = this.videoStream.getVideoTracks()[0];
      if (!track) return;

      try {
        const caps = track.getCapabilities ? track.getCapabilities() : {};
        if (caps.torch) {
          this.torchOn = !this.torchOn;
          await track.applyConstraints({ advanced: [{ torch: this.torchOn }] });
          QRUI.showToast(this.torchOn ? "Torch enabled" : "Torch disabled", "info");
        } else {
          QRUI.showToast("Torch is not supported by your camera hardware.", "warning");
        }
      } catch (e) {
        console.warn("Torch failed:", e);
      }
    }

    runScanLoop() {
      if (!this.scanning) return;
      const video = document.getElementById("scanner-video");
      if (video && video.readyState === video.HAVE_ENOUGH_DATA) {
        this.detectFromMediaElement(video)
          .then((result) => {
            if (result) {
              this.onQRCodeDetected(result);
            } else {
              this.animFrameId = requestAnimationFrame(() => this.runScanLoop());
            }
          })
          .catch(() => {
            this.animFrameId = requestAnimationFrame(() => this.runScanLoop());
          });
      } else {
        this.animFrameId = requestAnimationFrame(() => this.runScanLoop());
      }
    }

    bindUploadEvents() {
      const dropzone = document.getElementById("scanner-dropzone");
      const fileInput = document.getElementById("scanner-file-input");

      if (dropzone && fileInput) {
        dropzone.addEventListener("click", () => fileInput.click());

        dropzone.addEventListener("dragover", (e) => {
          e.preventDefault();
          dropzone.classList.add("dragover");
        });

        dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));

        dropzone.addEventListener("drop", (e) => {
          e.preventDefault();
          dropzone.classList.remove("dragover");
          if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            this.handleUploadedImageFile(e.dataTransfer.files[0]);
          }
        });

        fileInput.addEventListener("change", (e) => {
          if (e.target.files && e.target.files[0]) {
            this.handleUploadedImageFile(e.target.files[0]);
          }
        });
      }

      // Clipboard Paste listener (Ctrl+V)
      window.addEventListener("paste", (e) => {
        if (e.clipboardData && e.clipboardData.items) {
          for (let i = 0; i < e.clipboardData.items.length; i++) {
            const item = e.clipboardData.items[i];
            if (item.type.indexOf("image") !== -1) {
              const file = item.getAsFile();
              QRUI.showToast("Pasted image detected, analyzing...", "info");
              this.handleUploadedImageFile(file);
              break;
            }
          }
        }
      });
    }

    handleUploadedImageFile(file) {
      if (!file || !file.type.startsWith("image/")) {
        QRUI.showToast("Please select a valid image file.", "danger");
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = async () => {
          const result = await this.detectFromMediaElement(img);
          if (result) {
            this.onQRCodeDetected(result, e.target.result);
          } else {
            QRUI.showToast("No QR code found in this image. Try another image or higher resolution.", "warning", 4000);
          }
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
    }

    async detectFromMediaElement(mediaEl) {
      // 1. Try Native BarcodeDetector first
      if (this.barcodeDetector) {
        try {
          const barcodes = await this.barcodeDetector.detect(mediaEl);
          if (barcodes && barcodes.length > 0) {
            return barcodes[0].rawValue;
          }
        } catch (e) {
          // Fall through to jsQR
        }
      }

      // 2. jsQR fallback using canvas extraction
      if (window.jsQR) {
        let w = mediaEl.videoWidth || mediaEl.naturalWidth || mediaEl.width;
        let h = mediaEl.videoHeight || mediaEl.naturalHeight || mediaEl.height;
        if (!w || !h) return null;

        // Downscale very large photos for fast scanning
        const maxDim = 1000;
        let scale = 1;
        if (Math.max(w, h) > maxDim) {
          scale = maxDim / Math.max(w, h);
          w = Math.round(w * scale);
          h = Math.round(h * scale);
        }

        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        ctx.drawImage(mediaEl, 0, 0, w, h);
        const imgData = ctx.getImageData(0, 0, w, h);
        const code = jsQR(imgData.data, w, h, { inversionAttempts: "dontInvert" });
        if (code && code.data) {
          return code.data;
        }
      }

      return null;
    }

    onQRCodeDetected(rawData, originalImageSrc = null) {
      // Vibrate if mobile supported
      if (navigator.vibrate) {
        try { navigator.vibrate(100); } catch (e) {}
      }

      this.lastScanResult = rawData;
      const parsed = QRUtils.parseQRPayload(rawData);

      // Stop camera once found
      this.stopCamera();

      // Display Result Section
      const resultCard = document.getElementById("scan-result-card");
      if (!resultCard) return;

      resultCard.classList.add("visible");
      resultCard.scrollIntoView({ behavior: "smooth", block: "nearest" });

      // Title & Badge
      const titleEl = document.getElementById("scan-result-title");
      const badgeEl = document.getElementById("scan-result-type-badge");
      if (titleEl) titleEl.textContent = parsed.title;
      if (badgeEl) {
        badgeEl.textContent = parsed.type.toUpperCase();
        badgeEl.className = `badge badge-${parsed.type === "url" ? "primary" : "neutral"}`;
      }

      // Data display
      const dataEl = document.getElementById("scan-result-data");
      if (dataEl) {
        dataEl.innerHTML = `<strong>Decoded Content:</strong><br>${QRUtils.escapeHtml(parsed.raw)}`;
      }

      // Security Check Banner
      const secBanner = document.getElementById("scan-security-banner");
      if (secBanner) {
        if (parsed.isDangerous) {
          secBanner.className = "scan-security-banner security-warning";
          secBanner.innerHTML = `⚠️ <strong>Security Alert:</strong> The detected content uses an executable or suspicious scheme. Do not execute or download untrusted files.`;
        } else if (parsed.type === "url") {
          const domain = QRUtils.parseDomain(parsed.url);
          secBanner.className = "scan-security-banner security-safe";
          secBanner.innerHTML = `🛡️ <strong>Safe Link:</strong> Points to domain <strong>${QRUtils.escapeHtml(domain)}</strong>. Tap below when ready.`;
        } else {
          secBanner.className = "scan-security-banner security-safe";
          secBanner.innerHTML = `✅ <strong>Verified:</strong> Clean local QR code format (${parsed.type.toUpperCase()}).`;
        }
      }

      // Action: "Open Link" button visibility
      const openBtn = document.getElementById("btn-scan-open-link");
      if (openBtn) {
        if (parsed.url && !parsed.isDangerous) {
          openBtn.style.display = "inline-flex";
          openBtn.onclick = async () => {
            const confirmed = await QRUI.confirm(
              "Open External Link?",
              `You are about to visit:\n\n${parsed.url}\n\nDo you want to proceed?`,
              "Open Website"
            );
            if (confirmed) {
              window.open(parsed.url, "_blank", "noopener,noreferrer");
            }
          };
        } else {
          openBtn.style.display = "none";
        }
      }

      // Recreate Newly Generated QR Canvas
      const reconCanvas = document.getElementById("scanned-recreated-canvas");
      if (reconCanvas) {
        QREngine.renderToCanvas(reconCanvas, parsed.raw, {
          size: 256,
          margin: 2,
          fgColor: "#000000",
          bgColor: "#ffffff"
        });
      }

      // Display Original Image thumbnail if uploaded
      const origBox = document.getElementById("scanned-original-box");
      const origImg = document.getElementById("scanned-original-img");
      if (origBox && origImg) {
        if (originalImageSrc) {
          origBox.style.display = "flex";
          origImg.src = originalImageSrc;
        } else {
          origBox.style.display = "none";
        }
      }

      QRUI.showToast("QR Code successfully decoded!", "success");
    }

    bindActionEvents() {
      // 1. "Edit & Customize in Studio"
      const editBtn = document.getElementById("btn-scan-edit-studio");
      if (editBtn) {
        editBtn.addEventListener("click", () => {
          if (!this.lastScanResult) return;
          QRStorage.setDraft({
            payload: this.lastScanResult,
            design: { ...DEFAULT_QR_DESIGN }
          });
          if (global.QRRouter) {
            QRRouter.navigate("/editor");
          } else {
            window.location.href = "editor.html";
          }
        });
      }

      // 2. "Recreate & Download PNG"
      const reconBtn = document.getElementById("btn-scan-download-recreated");
      if (reconBtn) {
        reconBtn.addEventListener("click", () => {
          const canvas = document.getElementById("scanned-recreated-canvas");
          if (!canvas) return;
          const dataUrl = canvas.toDataURL("image/png");
          QRUtils.triggerDownload(dataUrl, `recreated-qr-${Date.now()}.png`);
          QRUI.showToast("Reconstructed QR downloaded!", "success");

          // Save to history
          QRStorage.saveHistoryItem({
            type: "scanned",
            title: `Scanned & Recreated QR`,
            data: this.lastScanResult,
            thumbnail: dataUrl
          });
        });
      }

      // 3. "Recreate & Download SVG"
      const reconSvgBtn = document.getElementById("btn-scan-download-svg");
      if (reconSvgBtn) {
        reconSvgBtn.addEventListener("click", () => {
          if (!this.lastScanResult) return;
          const svgStr = QREngine.renderToSVG(this.lastScanResult, DEFAULT_QR_DESIGN);
          const blob = new Blob([svgStr], { type: "image/svg+xml;charset=utf-8" });
          const url = URL.createObjectURL(blob);
          QRUtils.triggerDownload(url, `recreated-qr-${Date.now()}.svg`);
          setTimeout(() => URL.revokeObjectURL(url), 1000);
          QRUI.showToast("Reconstructed Vector SVG downloaded!", "success");
        });
      }

      // 4. "Copy Decoded Data"
      const copyBtn = document.getElementById("btn-scan-copy-data");
      if (copyBtn) {
        copyBtn.addEventListener("click", () => {
          if (this.lastScanResult) {
            QRUI.copyText(this.lastScanResult, "Decoded text copied to clipboard!");
          }
        });
      }

      // 5. "Scan Another Code"
      const resetBtn = document.getElementById("btn-scan-reset");
      if (resetBtn) {
        resetBtn.addEventListener("click", () => {
          const card = document.getElementById("scan-result-card");
          if (card) card.classList.remove("visible");
          this.lastScanResult = null;
          if (this.activeTab === "camera") {
            this.startCamera();
          }
        });
      }
    }
  }

  global.QRScanner = new QRScannerController();
})(typeof window !== "undefined" ? window : global);
