/**
 * QR STUDIO - STORAGE & PERSISTENCE
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  const STORAGE_KEYS = {
    HISTORY: "qr_studio_history_v1",
    SETTINGS: "qr_studio_settings_v1",
    CURRENT_DRAFT: "qr_studio_current_draft_v1"
  };

  const DEFAULT_SETTINGS = {
    theme: "dark",
    animationEnabled: true,
    animationType: "reveal",
    reducedMotion: "system",
    defaultSize: 512,
    defaultEcc: "M",
    defaultFormat: "png",
    defaultMargin: 2
  };

  const Storage = {
    // -------------------------------------------------------------
    // History Persistence
    // -------------------------------------------------------------
    getHistory() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.HISTORY);
        if (!raw) return [];
        return JSON.parse(raw);
      } catch (e) {
        console.warn("Storage.getHistory failed", e);
        return [];
      }
    },

    saveHistoryItem(item) {
      try {
        const history = this.getHistory();
        const historyItem = {
          id: item.id || "qr_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
          type: item.type || "text",
          title: item.title || "Custom QR Code",
          data: item.data || "",
          formData: item.formData || null,
          design: item.design || null,
          thumbnail: item.thumbnail || "",
          timestamp: item.timestamp || new Date().toISOString()
        };

        // Prepend to list and keep up to 60 items
        const updated = [historyItem, ...history.filter((h) => h.id !== historyItem.id)].slice(0, 60);
        localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(updated));
        return historyItem;
      } catch (e) {
        console.warn("Storage.saveHistoryItem failed", e);
        return null;
      }
    },

    deleteHistoryItem(id) {
      try {
        const history = this.getHistory();
        const updated = history.filter((h) => h.id !== id);
        localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(updated));
        return true;
      } catch (e) {
        console.warn("Storage.deleteHistoryItem failed", e);
        return false;
      }
    },

    clearHistory() {
      try {
        localStorage.removeItem(STORAGE_KEYS.HISTORY);
        return true;
      } catch (e) {
        console.warn("Storage.clearHistory failed", e);
        return false;
      }
    },

    // -------------------------------------------------------------
    // Settings Persistence
    // -------------------------------------------------------------
    getSettings() {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
        if (!raw) return { ...DEFAULT_SETTINGS };
        return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
      } catch (e) {
        return { ...DEFAULT_SETTINGS };
      }
    },

    updateSettings(partial) {
      try {
        const current = this.getSettings();
        const updated = { ...current, ...partial };
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(updated));
        return updated;
      } catch (e) {
        console.warn("Storage.updateSettings failed", e);
        return { ...DEFAULT_SETTINGS };
      }
    },

    resetSettings() {
      try {
        localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(DEFAULT_SETTINGS));
        return { ...DEFAULT_SETTINGS };
      } catch (e) {
        return { ...DEFAULT_SETTINGS };
      }
    },

    // -------------------------------------------------------------
    // Current Active Draft (Seamless transition Generator <-> Editor)
    // -------------------------------------------------------------
    getDraft() {
      try {
        const raw = sessionStorage.getItem(STORAGE_KEYS.CURRENT_DRAFT);
        if (!raw) return null;
        return JSON.parse(raw);
      } catch (e) {
        return null;
      }
    },

    setDraft(draft) {
      try {
        sessionStorage.setItem(STORAGE_KEYS.CURRENT_DRAFT, JSON.stringify(draft));
      } catch (e) {
        console.warn("Storage.setDraft failed", e);
      }
    }
  };

  global.QRStorage = Storage;
})(typeof window !== "undefined" ? window : global);
