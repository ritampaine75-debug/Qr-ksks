/**
 * QR STUDIO - UTILITIES & PROTOCOLS
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  const Utils = {
    // -------------------------------------------------------------
    // Security & Sanitization
    // -------------------------------------------------------------
    escapeHtml(str) {
      if (!str) return "";
      return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
    },

    isSuspiciousUrl(url) {
      if (!url) return false;
      const trimmed = url.trim().toLowerCase();
      // JavaScript, data URI, or vbscript execution attempts
      if (
        trimmed.startsWith("javascript:") ||
        trimmed.startsWith("vbscript:") ||
        (trimmed.startsWith("data:") && !trimmed.startsWith("data:image/"))
      ) {
        return true;
      }
      // Dangerous file extensions
      const dangerousExts = [".exe", ".apk", ".bat", ".cmd", ".vbs", ".msi", ".scr", ".sh"];
      for (const ext of dangerousExts) {
        if (trimmed.split("?")[0].endsWith(ext)) {
          return true;
        }
      }
      return false;
    },

    parseDomain(url) {
      try {
        const parsed = new URL(url);
        return parsed.hostname;
      } catch (e) {
        return url;
      }
    },

    // -------------------------------------------------------------
    // Data Protocol Formatters (All 21 Types)
    // -------------------------------------------------------------
    formatWifi(ssid, password, type = "WPA", hidden = false) {
      const escape = (s) => (s || "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/:/g, "\\:").replace(/,/g, "\\,");
      const h = hidden ? "true" : "false";
      return `WIFI:T:${type};S:${escape(ssid)};P:${escape(password)};H:${h};;`;
    },

    formatVCard(data) {
      const {
        firstName = "",
        lastName = "",
        org = "",
        title = "",
        phone = "",
        mobile = "",
        email = "",
        website = "",
        street = "",
        city = "",
        state = "",
        zip = "",
        country = ""
      } = data;

      let vcard = "BEGIN:VCARD\nVERSION:3.0\n";
      vcard += `N:${lastName};${firstName};;;\n`;
      vcard += `FN:${firstName} ${lastName}`.trim() + "\n";
      if (org) vcard += `ORG:${org}\n`;
      if (title) vcard += `TITLE:${title}\n`;
      if (phone) vcard += `TEL;TYPE=WORK,VOICE:${phone}\n`;
      if (mobile) vcard += `TEL;TYPE=CELL,VOICE:${mobile}\n`;
      if (email) vcard += `EMAIL;TYPE=PREF,INTERNET:${email}\n`;
      if (website) vcard += `URL:${website}\n`;
      if (street || city || state || zip || country) {
        vcard += `ADR;TYPE=WORK:;;${street};${city};${state};${zip};${country}\n`;
      }
      vcard += "END:VCARD";
      return vcard;
    },

    formatCalendarEvent(data) {
      const {
        title = "Event",
        description = "",
        location = "",
        start = "",
        end = "",
        allDay = false
      } = data;

      const formatIso = (dateStr) => {
        if (!dateStr) return "";
        const d = new Date(dateStr);
        if (isNaN(d.getTime())) return "";
        return d.toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
      };

      const dtStart = formatIso(start) || "20261003T100000Z";
      const dtEnd = formatIso(end) || "20261003T110000Z";

      let ics = "BEGIN:VCALENDAR\nVERSION:2.0\nBEGIN:VEVENT\n";
      ics += `SUMMARY:${title}\n`;
      if (description) ics += `DESCRIPTION:${description.replace(/\n/g, "\\n")}\n`;
      if (location) ics += `LOCATION:${location}\n`;
      ics += `DTSTART:${dtStart}\n`;
      ics += `DTEND:${dtEnd}\n`;
      ics += "END:VEVENT\nEND:VCALENDAR";
      return ics;
    },

    formatGeo(lat, lng) {
      return `geo:${lat},${lng}?q=${lat},${lng}`;
    },

    formatUPI(data) {
      const { pa = "", pn = "", am = "", tn = "", cu = "INR" } = data;
      const params = new URLSearchParams();
      if (pa) params.append("pa", pa);
      if (pn) params.append("pn", pn);
      if (am) params.append("am", am);
      if (tn) params.append("tn", tn);
      params.append("cu", cu);
      return `upi://pay?${params.toString()}`;
    },

    formatCrypto(coin, address, amount, message) {
      const coinLower = (coin || "bitcoin").toLowerCase();
      let prefix = "bitcoin";
      if (coinLower === "ethereum" || coinLower === "eth") prefix = "ethereum";
      else if (coinLower === "solana" || coinLower === "sol") prefix = "solana";
      else if (coinLower === "litecoin" || coinLower === "ltc") prefix = "litecoin";

      let uri = `${prefix}:${address}`;
      const params = [];
      if (amount) params.push(`amount=${encodeURIComponent(amount)}`);
      if (message) params.push(`message=${encodeURIComponent(message)}`);
      if (params.length > 0) uri += `?${params.join("&")}`;
      return uri;
    },

    formatWhatsApp(phone, text = "") {
      const cleanPhone = (phone || "").replace(/[^\d+]/g, "").replace(/^\+/, "");
      return `https://wa.me/${cleanPhone}${text ? `?text=${encodeURIComponent(text)}` : ""}`;
    },

    formatSMS(phone, message = "") {
      const cleanPhone = (phone || "").replace(/[^\d+]/g, "");
      return `sms:${cleanPhone}${message ? `?body=${encodeURIComponent(message)}` : ""}`;
    },

    formatMailto(email, subject = "", body = "") {
      let uri = `mailto:${email}`;
      const params = [];
      if (subject) params.push(`subject=${encodeURIComponent(subject)}`);
      if (body) params.push(`body=${encodeURIComponent(body)}`);
      if (params.length > 0) uri += `?${params.join("&")}`;
      return uri;
    },

    // -------------------------------------------------------------
    // Reverse QR Payload Parser (Intelligent Detection for Scanner)
    // -------------------------------------------------------------
    parseQRPayload(raw) {
      if (!raw) return { type: "text", title: "Empty Data", summary: "No data found", raw: "" };

      const trimmed = raw.trim();

      // 1. Wi-Fi
      if (/^WIFI:/i.test(trimmed)) {
        const ssidMatch = trimmed.match(/S:([^;]+)/);
        const passMatch = trimmed.match(/P:([^;]+)/);
        const typeMatch = trimmed.match(/T:([^;]+)/);
        const ssid = ssidMatch ? ssidMatch[1] : "Unknown Network";
        const type = typeMatch ? typeMatch[1] : "WPA/WPA2";
        const password = passMatch ? passMatch[1] : "None (Open)";
        return {
          type: "wifi",
          title: `Wi-Fi Network: ${ssid}`,
          summary: `Security: ${type} | Password: ${password}`,
          details: { ssid, password, type },
          raw
        };
      }

      // 2. vCard Contact
      if (/^BEGIN:VCARD/i.test(trimmed)) {
        const fnMatch = trimmed.match(/FN:(.+)/i);
        const telMatch = trimmed.match(/TEL.*:(.+)/i);
        const emailMatch = trimmed.match(/EMAIL.*:(.+)/i);
        const orgMatch = trimmed.match(/ORG:(.+)/i);
        const name = fnMatch ? fnMatch[1].trim() : "Contact Card";
        return {
          type: "vcard",
          title: `Contact: ${name}`,
          summary: `${telMatch ? telMatch[1].trim() : ""} ${emailMatch ? "• " + emailMatch[1].trim() : ""}`.trim() || orgMatch ? orgMatch[1] : "Digital Business Card",
          details: { name, phone: telMatch ? telMatch[1].trim() : "", email: emailMatch ? emailMatch[1].trim() : "", org: orgMatch ? orgMatch[1].trim() : "" },
          raw
        };
      }

      // 3. Calendar Event
      if (/^BEGIN:VCALENDAR/i.test(trimmed) || /^BEGIN:VEVENT/i.test(trimmed)) {
        const sumMatch = trimmed.match(/SUMMARY:(.+)/i);
        const locMatch = trimmed.match(/LOCATION:(.+)/i);
        const title = sumMatch ? sumMatch[1].trim() : "Calendar Event";
        return {
          type: "calendar",
          title: `Event: ${title}`,
          summary: locMatch ? `Location: ${locMatch[1].trim()}` : "iCalendar schedule entry",
          details: { title, location: locMatch ? locMatch[1].trim() : "" },
          raw
        };
      }

      // 4. UPI Payment
      if (/^upi:\/\/pay/i.test(trimmed)) {
        try {
          const url = new URL(trimmed);
          const pa = url.searchParams.get("pa") || "";
          const pn = url.searchParams.get("pn") || "";
          const am = url.searchParams.get("am") || "";
          return {
            type: "upi",
            title: `UPI Payment: ₹${am || "0.00"}`,
            summary: `Payee: ${pn || pa} (${pa})`,
            details: { pa, pn, am },
            raw
          };
        } catch (e) {
          return { type: "upi", title: "UPI Payment Request", summary: trimmed, raw };
        }
      }

      // 5. Crypto
      if (/^(bitcoin|ethereum|solana|litecoin):/i.test(trimmed)) {
        const parts = trimmed.split(":");
        const coin = parts[0];
        const rest = parts[1].split("?")[0];
        return {
          type: "crypto",
          title: `${coin.toUpperCase()} Address`,
          summary: rest,
          details: { coin, address: rest },
          raw
        };
      }

      // 6. WhatsApp
      if (/https:\/\/wa\.me\//i.test(trimmed) || /whatsapp:\/\//i.test(trimmed)) {
        return {
          type: "whatsapp",
          title: "WhatsApp Chat Link",
          summary: trimmed,
          url: trimmed,
          raw
        };
      }

      // 7. Geo Location
      if (/^geo:/i.test(trimmed)) {
        const coords = trimmed.replace(/^geo:/i, "").split("?")[0];
        return {
          type: "location",
          title: "Geo Coordinates",
          summary: coords,
          url: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(coords)}`,
          raw
        };
      }

      // 8. Mailto
      if (/^mailto:/i.test(trimmed)) {
        const email = trimmed.replace(/^mailto:/i, "").split("?")[0];
        return {
          type: "email",
          title: `Email Address: ${email}`,
          summary: trimmed,
          details: { email },
          raw
        };
      }

      // 9. Tel Phone
      if (/^tel:/i.test(trimmed)) {
        const phone = trimmed.replace(/^tel:/i, "");
        return {
          type: "phone",
          title: `Phone Number: ${phone}`,
          summary: phone,
          details: { phone },
          raw
        };
      }

      // 10. SMS
      if (/^sms:/i.test(trimmed)) {
        const phone = trimmed.replace(/^sms:/i, "").split("?")[0];
        return {
          type: "sms",
          title: `SMS Message: ${phone}`,
          summary: trimmed,
          details: { phone },
          raw
        };
      }

      // 11. Web URL
      if (/^https?:\/\//i.test(trimmed)) {
        const isDangerous = this.isSuspiciousUrl(trimmed);
        const domain = this.parseDomain(trimmed);
        return {
          type: "url",
          title: `Web URL: ${domain}`,
          summary: trimmed,
          url: trimmed,
          isDangerous,
          raw
        };
      }

      // Default: Plain Text
      return {
        type: "text",
        title: "Plain Text Data",
        summary: trimmed.length > 100 ? trimmed.substring(0, 100) + "..." : trimmed,
        raw
      };
    },

    // -------------------------------------------------------------
    // Color & Contrast Calculations (WCAG Luminance Standard)
    // -------------------------------------------------------------
    hexToRgb(hex) {
      if (!hex) return { r: 0, g: 0, b: 0, a: 1 };
      let cleanHex = hex.replace("#", "");
      if (cleanHex.length === 3) {
        cleanHex = cleanHex.split("").map((c) => c + c).join("");
      }
      const num = parseInt(cleanHex, 16);
      return {
        r: (num >> 16) & 255,
        g: (num >> 8) & 255,
        b: num & 255,
        a: 1
      };
    },

    getRelativeLuminance(hex) {
      const rgb = this.hexToRgb(hex);
      const toLinear = (c) => {
        const v = c / 255;
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
      };
      const R = toLinear(rgb.r);
      const G = toLinear(rgb.g);
      const B = toLinear(rgb.b);
      return 0.2126 * R + 0.7152 * G + 0.0722 * B;
    },

    getContrastRatio(fgHex, bgHex) {
      if (!fgHex || !bgHex) return 21;
      const l1 = this.getRelativeLuminance(fgHex);
      const l2 = this.getRelativeLuminance(bgHex);
      const lighter = Math.max(l1, l2);
      const darker = Math.min(l1, l2);
      return (lighter + 0.05) / (darker + 0.05);
    },

    evaluateScannability(opts) {
      const {
        fgColor = "#000000",
        bgColor = "#ffffff",
        transparentBg = false,
        hasLogo = false,
        logoSizeRatio = 0.2,
        eccLevel = "M",
        margin = 2
      } = opts;

      let score = 100;
      const issues = [];
      const suggestions = [];

      // 1. Contrast check
      if (transparentBg) {
        score -= 20;
        issues.push("Transparent background can fail on dark or textured surfaces.");
        suggestions.push("Ensure sufficient contrast against wherever the QR is placed.");
      } else {
        const contrast = this.getContrastRatio(fgColor, bgColor);
        if (contrast < 3.0) {
          score -= 45;
          issues.push(`Critically low contrast ratio (${contrast.toFixed(1)}:1).`);
          suggestions.push("Increase contrast between foreground and background.");
        } else if (contrast < 4.5) {
          score -= 20;
          issues.push(`Moderate contrast ratio (${contrast.toFixed(1)}:1).`);
          suggestions.push("Aim for at least 7:1 for instant camera recognition.");
        }
      }

      // 2. Logo vs Error Correction
      if (hasLogo) {
        if (eccLevel === "L") {
          score -= 35;
          issues.push("Logo used with Low (L ~7%) error correction will likely make QR unscannable.");
          suggestions.push("Switch Error Correction to High (H ~30%).");
        } else if (eccLevel === "M" && logoSizeRatio > 0.22) {
          score -= 20;
          issues.push("Large logo with Medium (M) error correction risks decode failures.");
          suggestions.push("Upgrade to High (H) error correction.");
        } else if (logoSizeRatio > 0.32) {
          score -= 15;
          issues.push("Logo covers over 30% of QR area.");
          suggestions.push("Reduce logo size slider to under 25%.");
        }
      }

      // 3. Margin / Quiet Zone
      if (margin < 1) {
        score -= 15;
        issues.push("Zero quiet zone margin may cause camera scan boundary failure.");
        suggestions.push("Set margin to at least 2 modules.");
      }

      score = Math.max(10, Math.min(100, score));

      let status = "Excellent";
      let badgeClass = "badge-success";
      if (score < 50) {
        status = "Critically Low";
        badgeClass = "badge-danger";
      } else if (score < 75) {
        status = "Needs Improvement";
        badgeClass = "badge-warning";
      } else if (score < 90) {
        status = "Good";
        badgeClass = "badge-primary";
      }

      return {
        score,
        status,
        badgeClass,
        issues,
        suggestions
      };
    },

    // -------------------------------------------------------------
    // Helper Download Triggers
    // -------------------------------------------------------------
    triggerDownload(dataUrl, filename) {
      const a = document.createElement("a");
      a.href = dataUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  global.QRUtils = Utils;
})(typeof window !== "undefined" ? window : global);
