/**
 * QR STUDIO - DESIGN STUDIO & EDITOR CONTROLLER
 * Full Customization: Colors, Gradients, Shapes, Eyes, Logos, Effects, ECC, Export
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  class QREditorController {
    constructor() {
      this.payload = "https://qrstudio.app";
      this.design = { ...DEFAULT_QR_DESIGN };
      this.debounceTimer = null;
    }

    init() {
      // Check for incoming draft from Generator, Scanner, or Template
      const draft = QRStorage.getDraft();
      if (draft) {
        if (draft.payload) this.payload = draft.payload;
        if (draft.design) this.design = { ...this.design, ...draft.design };
      }

      this.populateUIFromDesign();
      this.bindEvents();
      this.render();
    }

    populateUIFromDesign() {
      // Content
      const dataInput = document.getElementById("editor-qr-data");
      if (dataInput) dataInput.value = this.payload;

      // Colors
      const fgPicker = document.getElementById("editor-fg-color");
      const fgHex = document.getElementById("editor-fg-hex");
      if (fgPicker && fgHex) {
        fgPicker.value = this.design.fgColor;
        fgHex.value = this.design.fgColor;
      }

      const bgPicker = document.getElementById("editor-bg-color");
      const bgHex = document.getElementById("editor-bg-hex");
      if (bgPicker && bgHex) {
        bgPicker.value = this.design.bgColor;
        bgHex.value = this.design.bgColor;
      }

      const transCheck = document.getElementById("editor-bg-transparent");
      if (transCheck) transCheck.checked = Boolean(this.design.transparentBg);

      // Gradient
      const gradType = document.getElementById("editor-grad-type");
      if (gradType) gradType.value = this.design.gradientType || "none";
      const gradColor2 = document.getElementById("editor-grad-color2");
      const gradHex2 = document.getElementById("editor-grad-hex2");
      if (gradColor2 && gradHex2) {
        gradColor2.value = this.design.gradientColor2 || "#4f46e5";
        gradHex2.value = this.design.gradientColor2 || "#4f46e5";
      }
      const gradAngle = document.getElementById("editor-grad-angle");
      const gradAngleVal = document.getElementById("editor-grad-angle-val");
      if (gradAngle) gradAngle.value = this.design.gradientAngle || 45;
      if (gradAngleVal) gradAngleVal.textContent = `${this.design.gradientAngle || 45}°`;

      this.toggleGradientFields(this.design.gradientType);

      // Eye Outer / Inner Colors
      const eyeOuterColor = document.getElementById("editor-eye-outer-color");
      if (eyeOuterColor) eyeOuterColor.value = this.design.eyeOuterColor || this.design.fgColor;
      const eyeInnerColor = document.getElementById("editor-eye-inner-color");
      if (eyeInnerColor) eyeInnerColor.value = this.design.eyeInnerColor || this.design.fgColor;

      // Shapes & Eyes active tiles
      this.updateActiveTiles("module-style-tile", this.design.moduleStyle);
      this.updateActiveTiles("eye-outer-tile", this.design.eyeOuterStyle);
      this.updateActiveTiles("eye-inner-tile", this.design.eyeInnerStyle);

      // Logo settings
      const logoSize = document.getElementById("editor-logo-size");
      const logoSizeVal = document.getElementById("editor-logo-size-val");
      if (logoSize) logoSize.value = Math.round(this.design.logoSize * 100);
      if (logoSizeVal) logoSizeVal.textContent = `${Math.round(this.design.logoSize * 100)}%`;

      const logoPad = document.getElementById("editor-logo-pad");
      const logoPadVal = document.getElementById("editor-logo-pad-val");
      if (logoPad) logoPad.value = this.design.logoPadding;
      if (logoPadVal) logoPadVal.textContent = `${this.design.logoPadding} px`;

      const logoShape = document.getElementById("editor-logo-shape");
      if (logoShape) logoShape.value = this.design.logoBgShape;

      this.updateLogoPreviewUI();

      // Effects
      const effectSelect = document.getElementById("editor-effect-select");
      if (effectSelect) effectSelect.value = this.design.effect;

      // ECC
      this.updateActiveSegmented("ecc-segment-btn", this.design.ecc);

      // Size & Margin
      const marginSlider = document.getElementById("editor-margin-slider");
      const marginVal = document.getElementById("editor-margin-val");
      if (marginSlider) marginSlider.value = this.design.margin;
      if (marginVal) marginVal.textContent = `${this.design.margin}`;

      const sizeSlider = document.getElementById("editor-size-slider");
      const sizeVal = document.getElementById("editor-size-val");
      if (sizeSlider) sizeSlider.value = this.design.size;
      if (sizeVal) sizeVal.textContent = `${this.design.size}px`;
    }

    updateActiveTiles(className, activeValue) {
      document.querySelectorAll(`.${className}`).forEach((tile) => {
        tile.classList.toggle("active", tile.dataset.value === activeValue);
      });
    }

    updateActiveSegmented(className, activeValue) {
      document.querySelectorAll(`.${className}`).forEach((btn) => {
        btn.classList.toggle("active", btn.dataset.value === activeValue);
      });
    }

    toggleGradientFields(type) {
      const gradOptions = document.getElementById("gradient-options-row");
      if (gradOptions) {
        gradOptions.style.display = type && type !== "none" ? "flex" : "none";
      }
    }

    updateLogoPreviewUI() {
      const box = document.getElementById("editor-logo-preview-box");
      const img = document.getElementById("editor-logo-thumb");
      if (box && img) {
        if (this.design.logoSrc) {
          box.style.display = "flex";
          img.src = this.design.logoSrc;
        } else {
          box.style.display = "none";
        }
      }
    }

    bindEvents() {
      // 1. Data Content Input
      const dataInput = document.getElementById("editor-qr-data");
      if (dataInput) {
        dataInput.addEventListener("input", (e) => {
          this.payload = e.target.value.trim() || "https://qrstudio.app";
          this.scheduleRender();
        });
      }

      // 2. Colors: Foreground
      const fgPicker = document.getElementById("editor-fg-color");
      const fgHex = document.getElementById("editor-fg-hex");
      if (fgPicker && fgHex) {
        fgPicker.addEventListener("input", (e) => {
          this.design.fgColor = e.target.value;
          fgHex.value = e.target.value;
          this.scheduleRender();
        });
        fgHex.addEventListener("input", (e) => {
          if (/^#[0-9A-Fa-f]{6}$/.test(e.target.value)) {
            this.design.fgColor = e.target.value;
            fgPicker.value = e.target.value;
            this.scheduleRender();
          }
        });
      }

      // 3. Colors: Background
      const bgPicker = document.getElementById("editor-bg-color");
      const bgHex = document.getElementById("editor-bg-hex");
      if (bgPicker && bgHex) {
        bgPicker.addEventListener("input", (e) => {
          this.design.bgColor = e.target.value;
          bgHex.value = e.target.value;
          this.scheduleRender();
        });
        bgHex.addEventListener("input", (e) => {
          if (/^#[0-9A-Fa-f]{6}$/.test(e.target.value)) {
            this.design.bgColor = e.target.value;
            bgPicker.value = e.target.value;
            this.scheduleRender();
          }
        });
      }

      // 4. Transparent Background
      const transCheck = document.getElementById("editor-bg-transparent");
      if (transCheck) {
        transCheck.addEventListener("change", (e) => {
          this.design.transparentBg = e.target.checked;
          const stage = document.getElementById("editor-preview-stage");
          if (stage) stage.classList.toggle("transparent-checkered", e.target.checked);
          this.scheduleRender();
        });
      }

      // 5. Preset Color Swatches
      document.querySelectorAll(".fg-swatch").forEach((btn) => {
        btn.addEventListener("click", () => {
          const color = btn.dataset.color;
          this.design.fgColor = color;
          if (fgPicker) fgPicker.value = color;
          if (fgHex) fgHex.value = color;
          this.scheduleRender();
        });
      });

      document.querySelectorAll(".bg-swatch").forEach((btn) => {
        btn.addEventListener("click", () => {
          const color = btn.dataset.color;
          this.design.bgColor = color;
          if (bgPicker) bgPicker.value = color;
          if (bgHex) bgHex.value = color;
          if (transCheck) transCheck.checked = false;
          this.design.transparentBg = false;
          this.scheduleRender();
        });
      });

      // 6. Gradients
      const gradType = document.getElementById("editor-grad-type");
      if (gradType) {
        gradType.addEventListener("change", (e) => {
          this.design.gradientType = e.target.value;
          this.toggleGradientFields(e.target.value);
          this.scheduleRender();
        });
      }

      const gradColor2 = document.getElementById("editor-grad-color2");
      const gradHex2 = document.getElementById("editor-grad-hex2");
      if (gradColor2 && gradHex2) {
        gradColor2.addEventListener("input", (e) => {
          this.design.gradientColor2 = e.target.value;
          gradHex2.value = e.target.value;
          this.scheduleRender();
        });
        gradHex2.addEventListener("input", (e) => {
          if (/^#[0-9A-Fa-f]{6}$/.test(e.target.value)) {
            this.design.gradientColor2 = e.target.value;
            gradColor2.value = e.target.value;
            this.scheduleRender();
          }
        });
      }

      const gradAngle = document.getElementById("editor-grad-angle");
      const gradAngleVal = document.getElementById("editor-grad-angle-val");
      if (gradAngle) {
        gradAngle.addEventListener("input", (e) => {
          this.design.gradientAngle = parseInt(e.target.value, 10);
          if (gradAngleVal) gradAngleVal.textContent = `${e.target.value}°`;
          this.scheduleRender();
        });
      }

      // 7. Eye Outer & Inner Colors
      const eyeOuterColor = document.getElementById("editor-eye-outer-color");
      if (eyeOuterColor) {
        eyeOuterColor.addEventListener("input", (e) => {
          this.design.eyeOuterColor = e.target.value;
          this.scheduleRender();
        });
      }

      const eyeInnerColor = document.getElementById("editor-eye-inner-color");
      if (eyeInnerColor) {
        eyeInnerColor.addEventListener("input", (e) => {
          this.design.eyeInnerColor = e.target.value;
          this.scheduleRender();
        });
      }

      // 8. Module Shapes
      document.querySelectorAll(".module-style-tile").forEach((tile) => {
        tile.addEventListener("click", () => {
          this.design.moduleStyle = tile.dataset.value;
          this.updateActiveTiles("module-style-tile", tile.dataset.value);
          this.scheduleRender();
        });
      });

      // 9. Eye Styles
      document.querySelectorAll(".eye-outer-tile").forEach((tile) => {
        tile.addEventListener("click", () => {
          this.design.eyeOuterStyle = tile.dataset.value;
          this.updateActiveTiles("eye-outer-tile", tile.dataset.value);
          this.scheduleRender();
        });
      });

      document.querySelectorAll(".eye-inner-tile").forEach((tile) => {
        tile.addEventListener("click", () => {
          this.design.eyeInnerStyle = tile.dataset.value;
          this.updateActiveTiles("eye-inner-tile", tile.dataset.value);
          this.scheduleRender();
        });
      });

      // 10. Logo Upload & Presets
      const fileInput = document.getElementById("editor-logo-file-input");
      const dropzone = document.getElementById("editor-logo-dropzone");
      if (dropzone && fileInput) {
        dropzone.addEventListener("click", () => fileInput.click());
        dropzone.addEventListener("dragover", (e) => {
          e.preventDefault();
          dropzone.classList.add("dragover");
        });
        dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
        dropzone.addEventListener("drop", (e) => {
          e.preventDefault();
          dropzone.classList.remove("dragover");
          if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            this.handleLogoFile(e.dataTransfer.files[0]);
          }
        });
        fileInput.addEventListener("change", (e) => {
          if (e.target.files && e.target.files[0]) {
            this.handleLogoFile(e.target.files[0]);
          }
        });
      }

      document.querySelectorAll(".logo-preset-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          const logoName = btn.dataset.logo;
          this.design.logoSrc = `assets/logos/${logoName}.svg`;
          this.updateLogoPreviewUI();
          this.autoRecommendEccForLogo();
          this.scheduleRender();
        });
      });

      const removeLogoBtn = document.getElementById("btn-remove-logo");
      if (removeLogoBtn) {
        removeLogoBtn.addEventListener("click", () => {
          this.design.logoSrc = "";
          this.updateLogoPreviewUI();
          this.scheduleRender();
        });
      }

      const logoSize = document.getElementById("editor-logo-size");
      const logoSizeVal = document.getElementById("editor-logo-size-val");
      if (logoSize) {
        logoSize.addEventListener("input", (e) => {
          this.design.logoSize = parseInt(e.target.value, 10) / 100;
          if (logoSizeVal) logoSizeVal.textContent = `${e.target.value}%`;
          this.scheduleRender();
        });
      }

      const logoPad = document.getElementById("editor-logo-pad");
      const logoPadVal = document.getElementById("editor-logo-pad-val");
      if (logoPad) {
        logoPad.addEventListener("input", (e) => {
          this.design.logoPadding = parseInt(e.target.value, 10);
          if (logoPadVal) logoPadVal.textContent = `${e.target.value} px`;
          this.scheduleRender();
        });
      }

      const logoShape = document.getElementById("editor-logo-shape");
      if (logoShape) {
        logoShape.addEventListener("change", (e) => {
          this.design.logoBgShape = e.target.value;
          this.scheduleRender();
        });
      }

      // 11. Visual Effects
      const effectSelect = document.getElementById("editor-effect-select");
      if (effectSelect) {
        effectSelect.addEventListener("change", (e) => {
          this.design.effect = e.target.value;
          this.scheduleRender();
        });
      }

      // 12. Error Correction Level
      document.querySelectorAll(".ecc-segment-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          this.design.ecc = btn.dataset.value;
          this.updateActiveSegmented("ecc-segment-btn", btn.dataset.value);
          this.scheduleRender();
        });
      });

      // 13. Margin & Size Sliders
      const marginSlider = document.getElementById("editor-margin-slider");
      const marginVal = document.getElementById("editor-margin-val");
      if (marginSlider) {
        marginSlider.addEventListener("input", (e) => {
          this.design.margin = parseInt(e.target.value, 10);
          if (marginVal) marginVal.textContent = `${e.target.value}`;
          this.scheduleRender();
        });
      }

      const sizeSlider = document.getElementById("editor-size-slider");
      const sizeVal = document.getElementById("editor-size-val");
      if (sizeSlider) {
        sizeSlider.addEventListener("input", (e) => {
          this.design.size = parseInt(e.target.value, 10);
          if (sizeVal) sizeVal.textContent = `${e.target.value}px`;
          this.scheduleRender();
        });
      }

      // Size preset buttons
      document.querySelectorAll(".size-preset-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          const s = parseInt(btn.dataset.size, 10);
          this.design.size = s;
          if (sizeSlider) sizeSlider.value = s;
          if (sizeVal) sizeVal.textContent = `${s}px`;
          this.scheduleRender();
        });
      });

      // 14. "Optimize for Scanning / Safe Design"
      const safeBtn = document.getElementById("btn-safe-design-optimize");
      if (safeBtn) {
        safeBtn.addEventListener("click", () => {
          this.applySafeDesignOptimization();
        });
      }

      // 15. Export Handlers
      this.bindExportEvents();
    }

    handleLogoFile(file) {
      if (!file) return;
      if (!file.type.startsWith("image/")) {
        QRUI.showToast("Please upload a valid image file (PNG, JPG, SVG, WebP)", "danger");
        return;
      }
      const reader = new FileReader();
      reader.onload = (e) => {
        this.design.logoSrc = e.target.result;
        this.updateLogoPreviewUI();
        this.autoRecommendEccForLogo();
        this.scheduleRender();
        QRUI.showToast("Logo added successfully!", "success");
      };
      reader.readAsDataURL(file);
    }

    autoRecommendEccForLogo() {
      // Recommend High ECC when logo is added
      if (this.design.ecc !== "H" && this.design.ecc !== "Q") {
        this.design.ecc = "H";
        this.updateActiveSegmented("ecc-segment-btn", "H");
        QRUI.showToast("Error correction upgraded to High (H) for optimal logo scanning reliability.", "info");
      }
    }

    applySafeDesignOptimization() {
      // Set high contrast black on white, high ECC, safe margin of 2, clean square modules
      this.design.fgColor = "#000000";
      this.design.bgColor = "#ffffff";
      this.design.transparentBg = false;
      this.design.gradientType = "none";
      this.design.margin = Math.max(2, this.design.margin);
      this.design.ecc = "H";
      if (this.design.logoSrc && this.design.logoSize > 0.22) {
        this.design.logoSize = 0.2;
      }
      this.populateUIFromDesign();
      this.render();
      QRUI.showToast("Design optimized for 100% scan reliability!", "success");
    }

    scheduleRender() {
      if (this.debounceTimer) clearTimeout(this.debounceTimer);
      this.debounceTimer = setTimeout(() => {
        this.render();
      }, 70);
    }

    async render() {
      const canvas = document.getElementById("editor-qr-canvas");
      if (!canvas) return;

      const settings = QRStorage.getSettings();
      try {
        const result = await QREngine.renderToCanvas(canvas, this.payload, this.design);

        if (settings.animationEnabled) {
          const animClass = `animate-${settings.animationType || "reveal"}`;
          canvas.classList.remove("animate-reveal", "animate-fade-in", "animate-scale-in", "animate-pulse");
          void canvas.offsetWidth;
          canvas.classList.add(animClass);
        }

        this.updateScannabilityUI(result.scannability);

        const badge = document.getElementById("editor-modules-badge");
        if (badge) {
          badge.textContent = `${result.moduleCount}×${result.moduleCount} • ECC: ${this.design.ecc}`;
        }

        // Save active draft
        QRStorage.setDraft({
          payload: this.payload,
          design: this.design
        });
      } catch (err) {
        console.error("Editor render error:", err);
      }
    }

    updateScannabilityUI(scanInfo) {
      const barFill = document.getElementById("editor-scannability-bar-fill");
      const badge = document.getElementById("editor-scannability-badge");
      const feedback = document.getElementById("editor-scannability-feedback");

      if (barFill) {
        barFill.style.width = `${scanInfo.score}%`;
        barFill.style.backgroundColor = scanInfo.score >= 80 ? "var(--accent-success)" : scanInfo.score >= 50 ? "var(--accent-warning)" : "var(--accent-danger)";
      }

      if (badge) {
        badge.className = `badge ${scanInfo.badgeClass}`;
        badge.textContent = `${scanInfo.score}% • ${scanInfo.status}`;
      }

      if (feedback) {
        if (scanInfo.issues.length > 0) {
          feedback.innerHTML = `⚠️ <strong>Note:</strong> ${scanInfo.issues.join(" ")} ${scanInfo.suggestions.length ? `<br>💡 <em>Tip: ${scanInfo.suggestions[0]}</em>` : ""}`;
        } else {
          feedback.innerHTML = "✨ Excellent contrast and safe quiet zone. Guaranteed fast camera scanning.";
        }
      }
    }

    bindExportEvents() {
      const canvas = () => document.getElementById("editor-qr-canvas");

      // 1. Download PNG
      document.getElementById("btn-export-png")?.addEventListener("click", () => {
        const c = canvas();
        if (!c) return;
        const dataUrl = c.toDataURL("image/png");
        QRUtils.triggerDownload(dataUrl, `qr-studio-${Date.now()}.png`);
        QRUI.showToast("PNG downloaded successfully!", "success");
        this.saveCurrentToHistory(dataUrl);
      });

      // 2. Download SVG
      document.getElementById("btn-export-svg")?.addEventListener("click", () => {
        const svgStr = QREngine.renderToSVG(this.payload, this.design);
        const blob = new Blob([svgStr], { type: "image/svg+xml;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        QRUtils.triggerDownload(url, `qr-studio-${Date.now()}.svg`);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        QRUI.showToast("Scalable SVG downloaded successfully!", "success");
        this.saveCurrentToHistory();
      });

      // 3. Download JPEG
      document.getElementById("btn-export-jpeg")?.addEventListener("click", () => {
        const c = canvas();
        if (!c) return;
        // JPEGs must have solid background
        const tempCanvas = document.createElement("canvas");
        tempCanvas.width = c.width;
        tempCanvas.height = c.height;
        const tctx = tempCanvas.getContext("2d");
        tctx.fillStyle = this.design.bgColor || "#ffffff";
        tctx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
        tctx.drawImage(c, 0, 0);

        const dataUrl = tempCanvas.toDataURL("image/jpeg", 0.95);
        QRUtils.triggerDownload(dataUrl, `qr-studio-${Date.now()}.jpg`);
        QRUI.showToast("JPEG downloaded successfully!", "success");
        this.saveCurrentToHistory(dataUrl);
      });

      // 4. Download WebP
      document.getElementById("btn-export-webp")?.addEventListener("click", () => {
        const c = canvas();
        if (!c) return;
        const dataUrl = c.toDataURL("image/webp", 0.95);
        QRUtils.triggerDownload(dataUrl, `qr-studio-${Date.now()}.webp`);
        QRUI.showToast("WebP downloaded successfully!", "success");
        this.saveCurrentToHistory(dataUrl);
      });

      // 5. Copy to Clipboard
      document.getElementById("btn-copy-clipboard")?.addEventListener("click", async () => {
        const c = canvas();
        if (!c) return;
        try {
          c.toBlob(async (blob) => {
            if (blob && navigator.clipboard && navigator.clipboard.write) {
              await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
              QRUI.showToast("QR code copied to clipboard!", "success");
            } else {
              QRUI.showToast("Image clipboard not supported in this browser.", "warning");
            }
          });
        } catch (e) {
          QRUI.showToast("Failed to copy image", "danger");
        }
      });

      // 6. Copy SVG Code
      document.getElementById("btn-copy-svg-code")?.addEventListener("click", () => {
        const svgStr = QREngine.renderToSVG(this.payload, this.design);
        QRUI.copyText(svgStr, "Vector SVG markup copied to clipboard!");
      });

      // 7. Open in New Tab
      document.getElementById("btn-open-new-tab")?.addEventListener("click", () => {
        const c = canvas();
        if (!c) return;
        const dataUrl = c.toDataURL("image/png");
        const w = window.open("");
        if (w) {
          w.document.write(`<title>QR Studio - Preview</title><body style="margin:0;display:flex;align-items:center;justify-content:center;background:#0b0f19;min-height:100vh;"><img src="${dataUrl}" style="max-width:90%;border-radius:12px;box-shadow:0 10px 40px rgba(0,0,0,0.5);"></body>`);
        }
      });

      // 8. Print QR
      document.getElementById("btn-print-qr")?.addEventListener("click", () => {
        const c = canvas();
        if (!c) return;
        const dataUrl = c.toDataURL("image/png");
        const printWindow = window.open("", "_blank");
        if (printWindow) {
          printWindow.document.write(`
            <html>
              <head>
                <title>Print QR Code - QR Studio</title>
                <style>
                  body { font-family: sans-serif; text-align: center; padding: 40px; margin: 0; }
                  .qr-img { max-width: 380px; height: auto; margin-bottom: 20px; }
                  .title { font-size: 24px; font-weight: bold; margin-bottom: 8px; }
                  .data { font-size: 14px; color: #555; word-break: break-all; max-width: 480px; margin: 0 auto 20px; }
                  .footer { font-size: 11px; color: #888; border-top: 1px solid #ddd; padding-top: 12px; }
                </style>
              </head>
              <body>
                <div class="title">QR Studio Code</div>
                <img class="qr-img" src="${dataUrl}">
                <div class="data">${QRUtils.escapeHtml(this.payload)}</div>
                <div class="footer">Generated with QR Studio • Developed by Ritam</div>
                <script>
                  window.onload = function() { window.print(); window.close(); };
                <\/script>
              </body>
            </html>
          `);
        }
      });
    }

    saveCurrentToHistory(thumbnailUrl) {
      const c = document.getElementById("editor-qr-canvas");
      const thumb = thumbnailUrl || (c ? c.toDataURL("image/png") : "");
      QRStorage.saveHistoryItem({
        type: "custom",
        title: "Custom Designed QR",
        data: this.payload,
        thumbnail: thumb,
        design: this.design
      });
    }
  }

  global.QREditor = new QREditorController();
})(typeof window !== "undefined" ? window : global);
