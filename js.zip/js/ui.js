/**
 * QR STUDIO - UI & INTERACTION HELPERS
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  const UI = {
    // -------------------------------------------------------------
    // Toast Notification System
    // -------------------------------------------------------------
    showToast(message, type = "info", duration = 3200) {
      let container = document.getElementById("toast-container");
      if (!container) {
        container = document.createElement("div");
        container.id = "toast-container";
        container.className = "toast-container";
        document.body.appendChild(container);
      }

      const toast = document.createElement("div");
      toast.className = `toast toast-${type}`;

      let iconSvg = "";
      if (type === "success") {
        iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`;
      } else if (type === "danger") {
        iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
      } else if (type === "warning") {
        iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2.5"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
      } else {
        iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6366F1" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`;
      }

      toast.innerHTML = `
        <div style="flex-shrink: 0; display: flex; align-items: center;">${iconSvg}</div>
        <div style="flex: 1; line-height: 1.4;">${QRUtils.escapeHtml(message)}</div>
      `;

      container.appendChild(toast);

      setTimeout(() => {
        toast.style.animation = "toastFadeOut 0.25s forwards";
        setTimeout(() => {
          if (toast.parentNode) toast.parentNode.removeChild(toast);
        }, 260);
      }, duration);
    },

    // -------------------------------------------------------------
    // Modal System
    // -------------------------------------------------------------
    showModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.classList.add("active");
        document.body.style.overflow = "hidden";
      }
    },

    closeModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.classList.remove("active");
        document.body.style.overflow = "";
      }
    },

    confirm(title, message, confirmText = "Confirm", isDanger = false) {
      return new Promise((resolve) => {
        let overlay = document.getElementById("ui-confirm-modal");
        if (!overlay) {
          overlay = document.createElement("div");
          overlay.id = "ui-confirm-modal";
          overlay.className = "modal-overlay";
          overlay.innerHTML = `
            <div class="modal-dialog">
              <div class="modal-header">
                <h3 class="modal-title" id="ui-confirm-title">Confirm Action</h3>
                <button class="btn btn-ghost btn-sm" id="ui-confirm-close-btn">&times;</button>
              </div>
              <div class="modal-body">
                <p id="ui-confirm-message" style="color: var(--text-secondary); line-height: 1.5;"></p>
              </div>
              <div class="modal-footer">
                <button class="btn btn-secondary" id="ui-confirm-cancel">Cancel</button>
                <button class="btn" id="ui-confirm-ok">${confirmText}</button>
              </div>
            </div>
          `;
          document.body.appendChild(overlay);
        }

        const titleEl = document.getElementById("ui-confirm-title");
        const msgEl = document.getElementById("ui-confirm-message");
        const okBtn = document.getElementById("ui-confirm-ok");
        const cancelBtn = document.getElementById("ui-confirm-cancel");
        const closeBtn = document.getElementById("ui-confirm-close-btn");

        titleEl.textContent = title;
        msgEl.innerHTML = QRUtils.escapeHtml(message);
        okBtn.textContent = confirmText;
        okBtn.className = isDanger ? "btn btn-danger" : "btn btn-primary";

        const cleanup = (res) => {
          overlay.classList.remove("active");
          document.body.style.overflow = "";
          okBtn.onclick = null;
          cancelBtn.onclick = null;
          closeBtn.onclick = null;
          resolve(res);
        };

        okBtn.onclick = () => cleanup(true);
        cancelBtn.onclick = () => cleanup(false);
        closeBtn.onclick = () => cleanup(false);

        overlay.classList.add("active");
        document.body.style.overflow = "hidden";
      });
    },

    // -------------------------------------------------------------
    // Theme Management
    // -------------------------------------------------------------
    initTheme() {
      const settings = QRStorage.getSettings();
      this.applyTheme(settings.theme);

      // System preference listener
      window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
        const current = QRStorage.getSettings();
        if (current.theme === "system") {
          this.applyTheme("system");
        }
      });
    },

    applyTheme(theme) {
      let resolvedTheme = theme;
      if (theme === "system") {
        resolvedTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      }
      document.documentElement.setAttribute("data-theme", resolvedTheme);
      this.updateThemeIcons(resolvedTheme);
    },

    updateThemeIcons(resolvedTheme) {
      document.querySelectorAll(".theme-toggle-btn").forEach((btn) => {
        if (resolvedTheme === "light") {
          btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;
          btn.setAttribute("title", "Switch to Dark Mode");
          btn.setAttribute("aria-label", "Switch to Dark Mode");
        } else {
          btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`;
          btn.setAttribute("title", "Switch to Light Mode");
          btn.setAttribute("aria-label", "Switch to Light Mode");
        }
      });
    },

    toggleTheme() {
      const current = document.documentElement.getAttribute("data-theme") || "dark";
      const next = current === "dark" ? "light" : "dark";
      QRStorage.updateSettings({ theme: next });
      this.applyTheme(next);
      this.showToast(`Theme changed to ${next.toUpperCase()}`, "info", 1800);
    },

    // -------------------------------------------------------------
    // Accordion Initializer
    // -------------------------------------------------------------
    initAccordions() {
      document.querySelectorAll(".accordion-header, .control-card-header").forEach((header) => {
        if (!header._hasAccordionListener) {
          header._hasAccordionListener = true;
          header.addEventListener("click", () => {
            const card = header.closest(".accordion, .control-card");
            if (card) {
              card.classList.toggle("open");
            }
          });
        }
      });
    },

    // -------------------------------------------------------------
    // Clipboard Helper
    // -------------------------------------------------------------
    async copyText(text, successMsg = "Copied to clipboard!") {
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(text);
          this.showToast(successMsg, "success");
          return true;
        } else {
          // Fallback
          const ta = document.createElement("textarea");
          ta.value = text;
          ta.style.position = "fixed";
          ta.style.opacity = "0";
          document.body.appendChild(ta);
          ta.select();
          document.execCommand("copy");
          document.body.removeChild(ta);
          this.showToast(successMsg, "success");
          return true;
        }
      } catch (err) {
        this.showToast("Failed to copy to clipboard", "danger");
        return false;
      }
    }
  };

  global.QRUI = UI;
})(typeof window !== "undefined" ? window : global);
