/**
 * QR STUDIO - GENERATOR CONTROLLER
 * Manages 21 Data Types, Dynamic Forms, and Instant Live QR Previews
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  const TYPES = [
    { id: "url", name: "Website URL", icon: "url", desc: "Open websites or landing pages" },
    { id: "text", name: "Plain Text", icon: "text", desc: "Display any message or note" },
    { id: "wifi", name: "Wi-Fi Network", icon: "wifi", desc: "Connect automatically to Wi-Fi" },
    { id: "vcard", name: "vCard Contact", icon: "vcard", desc: "Save contact card directly to address book" },
    { id: "email", name: "Email Message", icon: "email", desc: "Draft an email with prefilled subject" },
    { id: "phone", name: "Phone Call", icon: "phone", desc: "Prompt an instant phone call" },
    { id: "sms", name: "SMS Message", icon: "sms", desc: "Send a text message" },
    { id: "whatsapp", name: "WhatsApp", icon: "whatsapp", desc: "Start a WhatsApp chat" },
    { id: "upi", name: "UPI Payment", icon: "upi", desc: "Instant UPI payments in India" },
    { id: "crypto", name: "Cryptocurrency", icon: "crypto", desc: "Bitcoin, Ethereum, Solana address" },
    { id: "calendar", name: "Calendar Event", icon: "calendar", desc: "Add an event with date and time" },
    { id: "location", name: "Geo Location", icon: "location", desc: "Map coordinates or location pin" },
    { id: "social", name: "Social Link", icon: "social", desc: "Link to social media profile" },
    { id: "app", name: "App Link", icon: "app", desc: "App Store or Google Play Store download" },
    { id: "youtube", name: "YouTube", icon: "youtube", desc: "Link to YouTube video or channel" },
    { id: "instagram", name: "Instagram", icon: "instagram", desc: "Open an Instagram profile" },
    { id: "facebook", name: "Facebook", icon: "facebook", desc: "Facebook profile or page" },
    { id: "twitter", name: "X / Twitter", icon: "twitter", desc: "X profile or share tweet" },
    { id: "telegram", name: "Telegram", icon: "telegram", desc: "Telegram channel or username" },
    { id: "linkedin", name: "LinkedIn", icon: "linkedin", desc: "LinkedIn profile or company page" },
    { id: "custom", name: "Custom Data", icon: "custom", desc: "Raw custom encoded data string" }
  ];

  class QRGeneratorController {
    constructor() {
      this.currentType = "url";
      this.currentPayload = "https://qrstudio.app";
      this.formData = {};
      this.currentDesign = { ...DEFAULT_QR_DESIGN };
      this.debounceTimer = null;
    }

    init() {
      this.renderTypeSelector();
      this.selectType(this.currentType);
      this.setupActionListeners();
    }

    renderTypeSelector() {
      const container = document.getElementById("generator-type-grid");
      if (!container) return;

      container.innerHTML = TYPES.map((t) => `
        <div class="type-card ${t.id === this.currentType ? "active" : ""}" data-type="${t.id}" tabindex="0" role="button" aria-label="${t.name}">
          <div class="type-icon">
            <img src="assets/icons/${t.icon}.svg" alt="" width="18" height="18" onerror="this.innerHTML='QR'">
          </div>
          <span class="type-title">${t.name}</span>
        </div>
      `).join("");

      container.querySelectorAll(".type-card").forEach((card) => {
        card.addEventListener("click", () => {
          this.selectType(card.dataset.type);
        });
        card.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            this.selectType(card.dataset.type);
          }
        });
      });

      // Type search filter
      const searchInput = document.getElementById("type-search-filter");
      if (searchInput) {
        searchInput.addEventListener("input", (e) => {
          const q = e.target.value.toLowerCase().trim();
          container.querySelectorAll(".type-card").forEach((card) => {
            const title = card.querySelector(".type-title").textContent.toLowerCase();
            card.style.display = title.includes(q) ? "flex" : "none";
          });
        });
      }
    }

    selectType(typeId) {
      this.currentType = typeId;
      document.querySelectorAll(".type-card").forEach((c) => {
        c.classList.toggle("active", c.dataset.type === typeId);
      });

      const typeObj = TYPES.find((t) => t.id === typeId) || TYPES[0];
      const titleEl = document.getElementById("generator-active-type-title");
      const descEl = document.getElementById("generator-active-type-desc");
      if (titleEl) titleEl.textContent = typeObj.name;
      if (descEl) descEl.textContent = typeObj.desc;

      this.renderDynamicFields(typeId);
      this.updatePayload();
    }

    renderDynamicFields(typeId) {
      const fieldsContainer = document.getElementById("dynamic-form-fields");
      if (!fieldsContainer) return;

      let html = "";
      switch (typeId) {
        case "url":
          html = `
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-url">Website URL</label>
              <input type="url" id="field-url" class="form-input" placeholder="https://example.com" value="https://qrstudio.app" required>
            </div>
          `;
          break;

        case "text":
          html = `
            <div class="form-group field-slide-enter">
              <div class="form-label">
                <span>Message or Content</span>
                <span id="field-text-counter" class="char-counter">0 chars</span>
              </div>
              <textarea id="field-text" class="form-textarea" rows="4" placeholder="Enter your text or note here...">Welcome to QR Studio!</textarea>
            </div>
          `;
          break;

        case "wifi":
          html = `
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-wifi-ssid">Network Name (SSID)</label>
              <input type="text" id="field-wifi-ssid" class="form-input" placeholder="Home or Office Wi-Fi" value="StudioGuest_5G">
            </div>
            <div class="form-row field-slide-enter">
              <div class="form-group">
                <label class="form-label" for="field-wifi-pass">Password</label>
                <input type="text" id="field-wifi-pass" class="form-input" placeholder="Network password" value="SecureWiFi2026">
              </div>
              <div class="form-group">
                <label class="form-label" for="field-wifi-type">Security</label>
                <select id="field-wifi-type" class="form-select">
                  <option value="WPA" selected>WPA/WPA2/WPA3</option>
                  <option value="WEP">WEP</option>
                  <option value="nopass">None (Open)</option>
                </select>
              </div>
            </div>
            <div class="form-group field-slide-enter">
              <label class="form-checkbox-label">
                <input type="checkbox" id="field-wifi-hidden" class="form-checkbox">
                <span>Hidden Network (SSID not broadcasted)</span>
              </label>
            </div>
          `;
          break;

        case "vcard":
          html = `
            <div class="form-row field-slide-enter">
              <div class="form-group">
                <label class="form-label" for="field-vcard-fn">First Name</label>
                <input type="text" id="field-vcard-fn" class="form-input" placeholder="John" value="Ritam">
              </div>
              <div class="form-group">
                <label class="form-label" for="field-vcard-ln">Last Name</label>
                <input type="text" id="field-vcard-ln" class="form-input" placeholder="Doe" value="Paine">
              </div>
            </div>
            <div class="form-row field-slide-enter">
              <div class="form-group">
                <label class="form-label" for="field-vcard-org">Company / Organization</label>
                <input type="text" id="field-vcard-org" class="form-input" placeholder="Company Name" value="QR Studio">
              </div>
              <div class="form-group">
                <label class="form-label" for="field-vcard-title">Job Title</label>
                <input type="text" id="field-vcard-title" class="form-input" placeholder="Designer / Engineer" value="Lead Developer">
              </div>
            </div>
            <div class="form-row field-slide-enter">
              <div class="form-group">
                <label class="form-label" for="field-vcard-phone">Work Phone</label>
                <input type="tel" id="field-vcard-phone" class="form-input" placeholder="+1 555-0199">
              </div>
              <div class="form-group">
                <label class="form-label" for="field-vcard-email">Email Address</label>
                <input type="email" id="field-vcard-email" class="form-input" placeholder="email@example.com" value="ritampaine75@gmail.com">
              </div>
            </div>
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-vcard-web">Website</label>
              <input type="url" id="field-vcard-web" class="form-input" placeholder="https://example.com" value="https://instagram.com/ritam_2024_0">
            </div>
          `;
          break;

        case "email":
          html = `
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-email-to">Recipient Email</label>
              <input type="email" id="field-email-to" class="form-input" placeholder="recipient@example.com" value="ritampaine75@gmail.com">
            </div>
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-email-sub">Subject</label>
              <input type="text" id="field-email-sub" class="form-input" placeholder="Email Subject" value="Inquiry via QR Studio">
            </div>
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-email-body">Message Body</label>
              <textarea id="field-email-body" class="form-textarea" rows="3" placeholder="Pre-filled email message..."></textarea>
            </div>
          `;
          break;

        case "phone":
          html = `
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-phone-num">Phone Number</label>
              <input type="tel" id="field-phone-num" class="form-input" placeholder="+1 234 567 8900" value="+15550199000">
            </div>
          `;
          break;

        case "sms":
          html = `
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-sms-phone">Phone Number</label>
              <input type="tel" id="field-sms-phone" class="form-input" placeholder="+1 234 567 8900" value="+15550199000">
            </div>
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-sms-msg">Message</label>
              <textarea id="field-sms-msg" class="form-textarea" rows="3" placeholder="Pre-filled SMS text...">Hello from QR Studio!</textarea>
            </div>
          `;
          break;

        case "whatsapp":
          html = `
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-wa-phone">Phone Number (with Country Code)</label>
              <input type="tel" id="field-wa-phone" class="form-input" placeholder="e.g. 919876543210 or 15551234567" value="919876543210">
            </div>
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-wa-text">Prefilled Chat Message</label>
              <textarea id="field-wa-text" class="form-textarea" rows="3" placeholder="Hello! I found your QR code...">Hi! Let's connect.</textarea>
            </div>
          `;
          break;

        case "upi":
          html = `
            <div class="form-row field-slide-enter">
              <div class="form-group">
                <label class="form-label" for="field-upi-pa">Virtual Payment Address (UPI ID)</label>
                <input type="text" id="field-upi-pa" class="form-input" placeholder="username@bank" value="payee@okaxis">
              </div>
              <div class="form-group">
                <label class="form-label" for="field-upi-pn">Payee Name</label>
                <input type="text" id="field-upi-pn" class="form-input" placeholder="Store or Individual Name" value="Ritam Studio">
              </div>
            </div>
            <div class="form-row field-slide-enter">
              <div class="form-group">
                <label class="form-label" for="field-upi-am">Amount (INR)</label>
                <input type="number" id="field-upi-am" class="form-input" placeholder="e.g. 250" value="100" min="0" step="any">
              </div>
              <div class="form-group">
                <label class="form-label" for="field-upi-tn">Transaction Note</label>
                <input type="text" id="field-upi-tn" class="form-input" placeholder="Payment for services" value="Order 101">
              </div>
            </div>
          `;
          break;

        case "crypto":
          html = `
            <div class="form-row field-slide-enter">
              <div class="form-group">
                <label class="form-label" for="field-crypto-coin">Cryptocurrency</label>
                <select id="field-crypto-coin" class="form-select">
                  <option value="bitcoin" selected>Bitcoin (BTC)</option>
                  <option value="ethereum">Ethereum (ETH)</option>
                  <option value="solana">Solana (SOL)</option>
                  <option value="litecoin">Litecoin (LTC)</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label" for="field-crypto-am">Amount (Optional)</label>
                <input type="text" id="field-crypto-am" class="form-input" placeholder="0.05">
              </div>
            </div>
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-crypto-addr">Wallet Address</label>
              <input type="text" id="field-crypto-addr" class="form-input font-mono" placeholder="Wallet public address" value="1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa">
            </div>
          `;
          break;

        case "calendar":
          html = `
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-cal-title">Event Title</label>
              <input type="text" id="field-cal-title" class="form-input" placeholder="Product Launch" value="QR Studio Launch Event">
            </div>
            <div class="form-row field-slide-enter">
              <div class="form-group">
                <label class="form-label" for="field-cal-start">Start Time</label>
                <input type="datetime-local" id="field-cal-start" class="form-input" value="2026-10-15T18:00">
              </div>
              <div class="form-group">
                <label class="form-label" for="field-cal-end">End Time</label>
                <input type="datetime-local" id="field-cal-end" class="form-input" value="2026-10-15T20:00">
              </div>
            </div>
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-cal-loc">Location</label>
              <input type="text" id="field-cal-loc" class="form-input" placeholder="Venue or Online link" value="https://meet.google.com">
            </div>
          `;
          break;

        case "location":
          html = `
            <div class="form-row field-slide-enter">
              <div class="form-group">
                <label class="form-label" for="field-geo-lat">Latitude</label>
                <input type="text" id="field-geo-lat" class="form-input" placeholder="22.5726" value="22.5726">
              </div>
              <div class="form-group">
                <label class="form-label" for="field-geo-lng">Longitude</label>
                <input type="text" id="field-geo-lng" class="form-input" placeholder="88.3639" value="88.3639">
              </div>
            </div>
          `;
          break;

        case "social":
        case "instagram":
        case "facebook":
        case "twitter":
        case "youtube":
        case "telegram":
        case "linkedin":
        case "app":
          const placeholders = {
            social: "https://bio.link/yourname",
            instagram: "https://instagram.com/ritam_2024_0",
            facebook: "https://facebook.com/yourpage",
            twitter: "https://x.com/ritam_2024_0",
            youtube: "https://youtube.com/@channel",
            telegram: "https://t.me/channel",
            linkedin: "https://linkedin.com/in/profile",
            app: "https://apps.apple.com/app/id123456"
          };
          html = `
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-social-link">Profile or Link URL</label>
              <input type="url" id="field-social-link" class="form-input" placeholder="https://..." value="${placeholders[typeId] || "https://qrstudio.app"}">
            </div>
          `;
          break;

        case "custom":
        default:
          html = `
            <div class="form-group field-slide-enter">
              <label class="form-label" for="field-custom-data">Raw Encoded Data</label>
              <textarea id="field-custom-data" class="form-textarea font-mono" rows="4" placeholder="Enter custom formatted QR data string...">CUSTOM_DATA:ID=987654</textarea>
            </div>
          `;
          break;
      }

      fieldsContainer.innerHTML = html;

      // Attach live input listeners to all inputs in dynamic container
      fieldsContainer.querySelectorAll("input, textarea, select").forEach((input) => {
        input.addEventListener("input", () => this.onInputChange());
        input.addEventListener("change", () => this.onInputChange());
      });
    }

    onInputChange() {
      if (this.debounceTimer) clearTimeout(this.debounceTimer);
      this.debounceTimer = setTimeout(() => {
        this.updatePayload();
      }, 80);
    }

    updatePayload() {
      let payload = "";
      const val = (id) => {
        const el = document.getElementById(id);
        return el ? el.value : "";
      };

      switch (this.currentType) {
        case "url":
          payload = val("field-url") || "https://qrstudio.app";
          break;

        case "text":
          payload = val("field-text") || "Hello from QR Studio!";
          const counter = document.getElementById("field-text-counter");
          if (counter) counter.textContent = `${payload.length} chars`;
          break;

        case "wifi":
          const ssid = val("field-wifi-ssid");
          const pass = val("field-wifi-pass");
          const type = val("field-wifi-type");
          const hidden = document.getElementById("field-wifi-hidden")?.checked || false;
          payload = QRUtils.formatWifi(ssid, pass, type, hidden);
          break;

        case "vcard":
          payload = QRUtils.formatVCard({
            firstName: val("field-vcard-fn"),
            lastName: val("field-vcard-ln"),
            org: val("field-vcard-org"),
            title: val("field-vcard-title"),
            phone: val("field-vcard-phone"),
            email: val("field-vcard-email"),
            website: val("field-vcard-web")
          });
          break;

        case "email":
          payload = QRUtils.formatMailto(val("field-email-to"), val("field-email-sub"), val("field-email-body"));
          break;

        case "phone":
          payload = `tel:${val("field-phone-num")}`;
          break;

        case "sms":
          payload = QRUtils.formatSMS(val("field-sms-phone"), val("field-sms-msg"));
          break;

        case "whatsapp":
          payload = QRUtils.formatWhatsApp(val("field-wa-phone"), val("field-wa-text"));
          break;

        case "upi":
          payload = QRUtils.formatUPI({
            pa: val("field-upi-pa"),
            pn: val("field-upi-pn"),
            am: val("field-upi-am"),
            tn: val("field-upi-tn")
          });
          break;

        case "crypto":
          payload = QRUtils.formatCrypto(val("field-crypto-coin"), val("field-crypto-addr"), val("field-crypto-am"), "");
          break;

        case "calendar":
          payload = QRUtils.formatCalendarEvent({
            title: val("field-cal-title"),
            start: val("field-cal-start"),
            end: val("field-cal-end"),
            location: val("field-cal-loc")
          });
          break;

        case "location":
          payload = QRUtils.formatGeo(val("field-geo-lat"), val("field-geo-lng"));
          break;

        case "social":
        case "instagram":
        case "facebook":
        case "twitter":
        case "youtube":
        case "telegram":
        case "linkedin":
        case "app":
          payload = val("field-social-link") || "https://qrstudio.app";
          break;

        case "custom":
        default:
          payload = val("field-custom-data") || "QR_STUDIO";
          break;
      }

      this.currentPayload = payload;
      this.renderPreview();
    }

    async renderPreview() {
      const canvas = document.getElementById("generator-qr-canvas");
      if (!canvas) return;

      const settings = QRStorage.getSettings();
      try {
        const result = await QREngine.renderToCanvas(canvas, this.currentPayload, {
          ...this.currentDesign,
          ecc: settings.defaultEcc || "M"
        });

        // Trigger animation if enabled
        if (settings.animationEnabled) {
          const animClass = `animate-${settings.animationType || "reveal"}`;
          canvas.classList.remove("animate-reveal", "animate-fade-in", "animate-scale-in", "animate-pulse");
          void canvas.offsetWidth; // trigger reflow
          canvas.classList.add(animClass);
        }

        // Update Scannability Meter
        this.updateScannabilityUI(result.scannability);

        // Update live stats badge
        const badge = document.getElementById("generator-modules-badge");
        if (badge) {
          badge.textContent = `${result.moduleCount}×${result.moduleCount} modules`;
        }

        // Keep active draft in session storage
        QRStorage.setDraft({
          type: this.currentType,
          payload: this.currentPayload,
          design: this.currentDesign
        });
      } catch (err) {
        console.error("Generator preview render error:", err);
      }
    }

    updateScannabilityUI(scanInfo) {
      const barFill = document.getElementById("scannability-bar-fill");
      const badge = document.getElementById("scannability-badge");
      const feedback = document.getElementById("scannability-feedback");

      if (barFill) {
        barFill.style.width = `${scanInfo.score}%`;
        barFill.style.backgroundColor = scanInfo.score >= 80 ? "var(--accent-success)" : scanInfo.score >= 50 ? "var(--accent-warning)" : "var(--accent-danger)";
      }

      if (badge) {
        badge.className = `badge ${scanInfo.badgeClass}`;
        badge.textContent = `${scanInfo.score}% • ${scanInfo.status}`;
      }

      if (feedback) {
        if (scanInfo.issues.length > 0) {
          feedback.textContent = scanInfo.issues[0];
        } else {
          feedback.textContent = "High contrast & standard quiet zone. Scans instantly on all devices.";
        }
      }
    }

    setupActionListeners() {
      // 1. "Customize in Editor"
      const editBtn = document.getElementById("btn-open-in-editor");
      if (editBtn) {
        editBtn.addEventListener("click", () => {
          QRStorage.setDraft({
            type: this.currentType,
            payload: this.currentPayload,
            design: this.currentDesign
          });
          if (global.QRRouter) {
            QRRouter.navigate("/editor");
          } else {
            window.location.href = "editor.html";
          }
        });
      }

      // 2. "Download PNG"
      const dlPngBtn = document.getElementById("btn-quick-download-png");
      if (dlPngBtn) {
        dlPngBtn.addEventListener("click", () => {
          const canvas = document.getElementById("generator-qr-canvas");
          if (!canvas) return;
          const dataUrl = canvas.toDataURL("image/png");
          const filename = `qr-studio-${this.currentType}-${Date.now()}.png`;
          QRUtils.triggerDownload(dataUrl, filename);
          QRUI.showToast("PNG downloaded successfully!", "success");

          // Save to history
          QRStorage.saveHistoryItem({
            type: this.currentType,
            title: document.getElementById("generator-active-type-title")?.textContent || "Generated QR",
            data: this.currentPayload,
            thumbnail: dataUrl,
            design: this.currentDesign
          });
        });
      }

      // 3. "Download SVG"
      const dlSvgBtn = document.getElementById("btn-quick-download-svg");
      if (dlSvgBtn) {
        dlSvgBtn.addEventListener("click", () => {
          const svgStr = QREngine.renderToSVG(this.currentPayload, this.currentDesign);
          const blob = new Blob([svgStr], { type: "image/svg+xml;charset=utf-8" });
          const url = URL.createObjectURL(blob);
          const filename = `qr-studio-${this.currentType}-${Date.now()}.svg`;
          QRUtils.triggerDownload(url, filename);
          setTimeout(() => URL.revokeObjectURL(url), 1000);
          QRUI.showToast("Vector SVG downloaded successfully!", "success");
        });
      }

      // 4. "Copy Image"
      const copyImgBtn = document.getElementById("btn-quick-copy-img");
      if (copyImgBtn) {
        copyImgBtn.addEventListener("click", async () => {
          const canvas = document.getElementById("generator-qr-canvas");
          if (!canvas) return;
          try {
            canvas.toBlob(async (blob) => {
              if (blob && navigator.clipboard && navigator.clipboard.write) {
                await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
                QRUI.showToast("QR Image copied to clipboard!", "success");
              } else {
                QRUI.showToast("Clipboard image copy not supported in this browser.", "warning");
              }
            });
          } catch (e) {
            QRUI.showToast("Failed to copy image to clipboard", "danger");
          }
        });
      }

      // 5. "Copy Data"
      const copyDataBtn = document.getElementById("btn-quick-copy-data");
      if (copyDataBtn) {
        copyDataBtn.addEventListener("click", () => {
          QRUI.copyText(this.currentPayload, "Encoded QR text copied!");
        });
      }
    }
  }

  global.QRGenerator = new QRGeneratorController();
})(typeof window !== "undefined" ? window : global);
