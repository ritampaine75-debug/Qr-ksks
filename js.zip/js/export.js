/**
 * QR STUDIO - EXPORT CONTROLLER
 * High-Resolution PNG, SVG Vector, JPEG, WebP, Print Engine, and Clipboard Sharing
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  const ExportEngine = {
    /**
     * Export Canvas to high-resolution PNG
     */
    async exportPNG(payload, designOptions = {}, resolution = 1024) {
      const canvas = document.createElement("canvas");
      await QREngine.renderToCanvas(canvas, payload, {
        ...designOptions,
        size: resolution
      });
      return canvas.toDataURL("image/png");
    },

    /**
     * Export Canvas to JPEG with background
     */
    async exportJPEG(payload, designOptions = {}, resolution = 1024, quality = 0.95) {
      const canvas = document.createElement("canvas");
      await QREngine.renderToCanvas(canvas, payload, {
        ...designOptions,
        size: resolution,
        transparentBg: false
      });
      return canvas.toDataURL("image/jpeg", quality);
    },

    /**
     * Export Canvas to WebP
     */
    async exportWebP(payload, designOptions = {}, resolution = 1024, quality = 0.95) {
      const canvas = document.createElement("canvas");
      await QREngine.renderToCanvas(canvas, payload, {
        ...designOptions,
        size: resolution
      });
      return canvas.toDataURL("image/webp", quality);
    },

    /**
     * Generate Vector SVG string
     */
    exportSVG(payload, designOptions = {}) {
      return QREngine.renderToSVG(payload, designOptions);
    },

    /**
     * Print QR Code Sheet with clean layout
     */
    async printSheet(payload, designOptions = {}, title = "QR Code") {
      const canvas = document.createElement("canvas");
      await QREngine.renderToCanvas(canvas, payload, {
        ...designOptions,
        size: 800
      });
      const dataUrl = canvas.toDataURL("image/png");

      const printWindow = window.open("", "_blank");
      if (!printWindow) {
        QRUI.showToast("Popup blocked! Please allow popups to print.", "warning");
        return;
      }

      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <title>${QRUtils.escapeHtml(title)} - Print Sheet</title>
            <style>
              @page { size: auto; margin: 20mm; }
              body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                text-align: center;
                color: #0f172a;
                padding: 20px;
                margin: 0;
              }
              .sheet-card {
                max-width: 440px;
                margin: 40px auto;
                padding: 40px;
                border: 2px solid #e2e8f0;
                border-radius: 20px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.06);
              }
              .qr-image {
                width: 100%;
                max-width: 320px;
                height: auto;
                margin-bottom: 24px;
              }
              .sheet-title {
                font-size: 22px;
                font-weight: 800;
                margin-bottom: 8px;
              }
              .sheet-data {
                font-size: 13px;
                color: #64748b;
                word-break: break-all;
                margin-bottom: 24px;
                line-height: 1.4;
              }
              .sheet-footer {
                font-size: 11px;
                color: #94a3b8;
                border-top: 1px solid #f1f5f9;
                padding-top: 16px;
              }
            </style>
          </head>
          <body>
            <div class="sheet-card">
              <div class="sheet-title">${QRUtils.escapeHtml(title)}</div>
              <div class="sheet-data">${QRUtils.escapeHtml(payload)}</div>
              <img class="qr-image" src="${dataUrl}" alt="QR Code">
              <div class="sheet-footer">
                Printed with <strong>QR Studio</strong> • Developed by Ritam
              </div>
            </div>
            <script>
              window.onload = function() {
                window.print();
                setTimeout(() => window.close(), 1000);
              };
            <\/script>
          </body>
        </html>
      `);
      printWindow.document.close();
    }
  };

  global.QRExport = ExportEngine;
})(typeof window !== "undefined" ? window : global);
