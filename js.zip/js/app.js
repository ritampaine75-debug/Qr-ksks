/**
 * QR STUDIO - MAIN APPLICATION BOOTSTRAPPER
 * Developed by Ritam | ritampaine75@gmail.com | @ritam_2024_0
 */

(function(global) {
  "use strict";

  // -------------------------------------------------------------
  // Settings Page Logic
  // -------------------------------------------------------------
  class SettingsController {
    init() {
      const settings = QRStorage.getSettings();

      // Theme Select
      const themeSelect = document.getElementById("setting-theme-select");
      if (themeSelect) {
        themeSelect.value = settings.theme;
        themeSelect.addEventListener("change", (e) => {
          QRStorage.updateSettings({ theme: e.target.value });
          QRUI.applyTheme(e.target.value);
          QRUI.showToast("Theme updated", "info");
        });
      }

      // Animation Toggle
      const animToggle = document.getElementById("setting-anim-toggle");
      if (animToggle) {
        animToggle.checked = Boolean(settings.animationEnabled);
        animToggle.addEventListener("change", (e) => {
          QRStorage.updateSettings({ animationEnabled: e.target.checked });
          QRUI.showToast(`Animations ${e.target.checked ? "enabled" : "disabled"}`, "info");
        });
      }

      // Animation Style Select
      const animTypeSelect = document.getElementById("setting-anim-type");
      if (animTypeSelect) {
        animTypeSelect.value = settings.animationType || "reveal";
        animTypeSelect.addEventListener("change", (e) => {
          QRStorage.updateSettings({ animationType: e.target.value });
        });
      }

      // Default Size Select
      const sizeSelect = document.getElementById("setting-default-size");
      if (sizeSelect) {
        sizeSelect.value = settings.defaultSize;
        sizeSelect.addEventListener("change", (e) => {
          QRStorage.updateSettings({ defaultSize: parseInt(e.target.value, 10) });
          QRUI.showToast("Default QR size saved", "info");
        });
      }

      // Default ECC Select
      const eccSelect = document.getElementById("setting-default-ecc");
      if (eccSelect) {
        eccSelect.value = settings.defaultEcc;
        eccSelect.addEventListener("change", (e) => {
          QRStorage.updateSettings({ defaultEcc: e.target.value });
          QRUI.showToast("Default Error Correction saved", "info");
        });
      }

      // Default Format Select
      const formatSelect = document.getElementById("setting-default-format");
      if (formatSelect) {
        formatSelect.value = settings.defaultFormat;
        formatSelect.addEventListener("change", (e) => {
          QRStorage.updateSettings({ defaultFormat: e.target.value });
          QRUI.showToast("Default export format saved", "info");
        });
      }

      // Storage Info
      const historyCountEl = document.getElementById("settings-history-count");
      if (historyCountEl) {
        const history = QRStorage.getHistory();
        historyCountEl.textContent = `${history.length} saved QR codes`;
      }

      // Reset All Settings Button
      const resetBtn = document.getElementById("btn-reset-settings");
      if (resetBtn) {
        resetBtn.addEventListener("click", async () => {
          const confirmed = await QRUI.confirm(
            "Reset Settings?",
            "Are you sure you want to restore all application settings back to defaults?",
            "Reset Defaults",
            true
          );
          if (confirmed) {
            QRStorage.resetSettings();
            this.init();
            QRUI.applyTheme("dark");
            QRUI.showToast("Settings restored to defaults", "success");
          }
        });
      }

      // Clear History from Settings
      const clearHistBtn = document.getElementById("btn-settings-clear-history");
      if (clearHistBtn) {
        clearHistBtn.addEventListener("click", async () => {
          const confirmed = await QRUI.confirm(
            "Clear History?",
            "Are you sure you want to delete all saved QR codes from local storage?",
            "Clear History",
            true
          );
          if (confirmed) {
            QRStorage.clearHistory();
            if (historyCountEl) historyCountEl.textContent = "0 saved QR codes";
            QRUI.showToast("History cleared successfully", "success");
          }
        });
      }
    }
  }

  global.QRSettings = new SettingsController();

  // -------------------------------------------------------------
  // App Bootstrapper
  // -------------------------------------------------------------
  document.addEventListener("DOMContentLoaded", () => {
    // 1. Initialize Theme
    QRUI.initTheme();

    // 2. Setup theme toggle buttons
    document.querySelectorAll(".theme-toggle-btn").forEach((btn) => {
      btn.addEventListener("click", () => QRUI.toggleTheme());
    });

    // 3. Initialize Accordions
    QRUI.initAccordions();

    // 4. Initialize Router
    if (global.QRRouter) {
      QRRouter.init();
    }

    // 5. Initialize active page controller if direct standalone page
    const pageId = document.body.dataset.page;
    if (pageId === "generator" && global.QRGenerator) global.QRGenerator.init();
    if (pageId === "editor" && global.QREditor) global.QREditor.init();
    if (pageId === "scanner" && global.QRScanner) global.QRScanner.init();
    if (pageId === "templates" && global.QRTemplates) global.QRTemplates.init();
    if (pageId === "history" && global.QRHistory) global.QRHistory.init();
    if (pageId === "settings" && global.QRSettings) global.QRSettings.init();

    // 6. Register Service Worker for PWA & Offline Support
    if ("serviceWorker" in navigator && (window.location.protocol === "http:" || window.location.protocol === "https:")) {
      navigator.serviceWorker.register("service-worker.js")
        .then(() => console.log("QR Studio: Service Worker active"))
        .catch((e) => console.log("QR Studio: Service Worker registration skipped", e));
    }
  });

})(typeof window !== "undefined" ? window : global);
